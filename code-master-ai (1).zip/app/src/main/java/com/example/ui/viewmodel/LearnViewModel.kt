package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.ModuleEntity
import com.example.data.repository.CourseRepository
import com.example.data.repository.ProgressRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class LearnUiState(
    val courses: List<CourseEntity> = emptyList(),
    val selectedCategory: String = "All",
    val searchQuery: String = "",
    val selectedCourse: CourseEntity? = null,
    val courseModules: List<ModuleEntity> = emptyList(),
    val courseLessons: List<LessonEntity> = emptyList(),
    val completedLessonIds: Set<String> = emptySet(),
    val courseProgressPercent: Int = 0
)

class LearnViewModel(
    private val courseRepository: CourseRepository,
    private val progressRepository: ProgressRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LearnUiState())
    val uiState: StateFlow<LearnUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            courseRepository.getAllPublishedCoursesFlow().collect { list ->
                _uiState.update { it.copy(courses = list) }
            }
        }
    }

    fun selectCategory(cat: String) {
        _uiState.update { it.copy(selectedCategory = cat) }
    }

    fun searchCourses(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun selectCourse(courseId: String, currentUid: String) {
        viewModelScope.launch {
            val course = courseRepository.getCourseById(courseId)
            _uiState.update { it.copy(selectedCourse = course) }

            courseRepository.getModulesForCourseFlow(courseId).collect { modules ->
                _uiState.update { it.copy(courseModules = modules) }
            }
        }
        viewModelScope.launch {
            courseRepository.getLessonsForCourseFlow(courseId).collect { lessons ->
                _uiState.update { it.copy(courseLessons = lessons) }
            }
        }
        viewModelScope.launch {
            progressRepository.getProgressFlow(currentUid, courseId).collect { progress ->
                val completedSet = progress?.completedLessonIds?.split(",")?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
                _uiState.update {
                    it.copy(
                        completedLessonIds = completedSet,
                        courseProgressPercent = progress?.percentCompleted ?: 0
                    )
                }
            }
        }
    }
}
