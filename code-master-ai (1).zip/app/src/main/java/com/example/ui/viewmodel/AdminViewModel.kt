package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.CertificateEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.UserEntity
import com.example.data.repository.AuthRepository
import com.example.data.repository.CourseRepository
import com.example.data.repository.ProgressRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

data class AdminUiState(
    val students: List<UserEntity> = emptyList(),
    val courses: List<CourseEntity> = emptyList(),
    val certificates: List<CertificateEntity> = emptyList(),
    val searchQuery: String = "",
    val totalStudentsCount: Int = 0,
    val activeStudentsCount: Int = 0,
    val totalCertificatesIssued: Int = 0,
    val statusMessage: String? = null
)

class AdminViewModel(
    private val authRepository: AuthRepository,
    private val courseRepository: CourseRepository,
    private val progressRepository: ProgressRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    fun loadData() {
        viewModelScope.launch {
            authRepository.getAllStudentsFlow().collect { students ->
                _uiState.update {
                    it.copy(
                        students = students,
                        totalStudentsCount = students.size,
                        activeStudentsCount = students.count { s -> s.accountStatus == "active" }
                    )
                }
            }
        }
        viewModelScope.launch {
            courseRepository.getAllCoursesAdminFlow().collect { courses ->
                _uiState.update { it.copy(courses = courses) }
            }
        }
        viewModelScope.launch {
            progressRepository.getAllCertificatesFlow().collect { certs ->
                _uiState.update {
                    it.copy(
                        certificates = certs,
                        totalCertificatesIssued = certs.size
                    )
                }
            }
        }
    }

    fun searchStudents(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        viewModelScope.launch {
            if (query.isBlank()) {
                authRepository.getAllStudentsFlow().collect { students ->
                    _uiState.update { it.copy(students = students) }
                }
            } else {
                authRepository.searchStudentsFlow(query).collect { filtered ->
                    _uiState.update { it.copy(students = filtered) }
                }
            }
        }
    }

    fun toggleStudentAccountStatus(targetUid: String, currentStatus: String) {
        viewModelScope.launch {
            val newStatus = if (currentStatus == "active") "deactivated" else "active"
            authRepository.toggleAccountStatus(targetUid, newStatus)
            _uiState.update { it.copy(statusMessage = "Student status updated to $newStatus") }
        }
    }

    fun createCourse(title: String, category: String, description: String, level: String) {
        viewModelScope.launch {
            val newCourse = CourseEntity(
                courseId = "course_" + UUID.randomUUID().toString().take(8),
                title = title,
                description = description,
                category = category,
                iconName = "code",
                level = level,
                estimatedHours = 10,
                totalLessons = 5,
                totalQuizzes = 2,
                totalProjects = 1,
                badgeName = "$title Master",
                isPublished = true
            )
            courseRepository.saveCourse(newCourse)
            _uiState.update { it.copy(statusMessage = "Course '$title' published successfully!") }
        }
    }

    fun deleteCourse(courseId: String) {
        viewModelScope.launch {
            courseRepository.deleteCourse(courseId)
            _uiState.update { it.copy(statusMessage = "Course removed.") }
        }
    }
}
