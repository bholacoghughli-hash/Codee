package com.example.ui.screens.lesson

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CodeSnippetCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.LessonViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonScreen(
    viewModel: LessonViewModel,
    lessonId: String,
    currentUid: String,
    onBack: () -> Unit,
    onOpenAiTutor: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val lesson = uiState.lesson

    LaunchedEffect(lessonId) {
        viewModel.loadLesson(lessonId, currentUid)
    }

    var showSolution by remember { mutableStateOf(false) }
    var noteInput by remember { mutableStateOf("") }
    var showCompletionDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.noteText) {
        noteInput = uiState.noteText
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = lesson?.title ?: "Lesson Details",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Language Switcher
                    var langMenuExpanded by remember { mutableStateOf(false) }
                    Box {
                        IconButton(onClick = { langMenuExpanded = true }) {
                            Icon(Icons.Outlined.Translate, contentDescription = "Translate")
                        }
                        DropdownMenu(
                            expanded = langMenuExpanded,
                            onDismissRequest = { langMenuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("English") },
                                onClick = { viewModel.setLanguage("English"); langMenuExpanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Hindi (हिंदी)") },
                                onClick = { viewModel.setLanguage("Hindi"); langMenuExpanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Hinglish") },
                                onClick = { viewModel.setLanguage("Hinglish"); langMenuExpanded = false }
                            )
                        }
                    }

                    // TTS Audio Button
                    IconButton(onClick = { viewModel.toggleTts() }) {
                        Icon(
                            if (uiState.isTtsPlaying) Icons.Filled.VolumeUp else Icons.Outlined.VolumeUp,
                            contentDescription = "Read Aloud",
                            tint = if (uiState.isTtsPlaying) CyanPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Bookmark Button
                    IconButton(onClick = { viewModel.toggleBookmark(currentUid) }) {
                        Icon(
                            if (uiState.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (uiState.isBookmarked) AmberWarning else MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onOpenAiTutor,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = IndigoAccent, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ask AI Tutor", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            viewModel.markLessonComplete(currentUid) {
                                showCompletionDialog = true
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("complete_lesson_button")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Complete", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { paddingValues ->
        if (lesson == null) {
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CyanPrimary)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // "Explain Simply" Mode Toggle Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (uiState.isEasyModeEnabled) EmeraldSuccess.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = if (uiState.isEasyModeEnabled) EmeraldSuccess else IndigoAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Explain Simply (Beginner Mode)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Translates complex concepts to everyday analogies", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Switch(
                            checked = uiState.isEasyModeEnabled,
                            onCheckedChange = { viewModel.toggleEasyMode() },
                            modifier = Modifier.testTag("easy_mode_switch")
                        )
                    }
                }

                // Objective Card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Outlined.Flag, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Learning Objective", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CyanPrimary)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(lesson.objective, fontSize = 13.sp, lineHeight = 18.sp)
                        }
                    }
                }

                // Core Explanation
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Concept Explanation", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (uiState.isEasyModeEnabled) lesson.simplifiedExplanation else lesson.simpleExplanation,
                            fontSize = 14.sp,
                            lineHeight = 22.sp
                        )
                    }
                }

                // Real-Life Analogy
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AmberWarning.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth().border(1.dp, AmberWarning.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Real-Life Analogy", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AmberWarning)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(lesson.realLifeAnalogy, fontSize = 13.sp, lineHeight = 19.sp)
                        }
                    }
                }

                // Visual Diagram Box
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CodeBackground,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Mental Model Diagram", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyanPrimary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = lesson.visualDiagram,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = Color.White
                        )
                    }
                }

                // Code Example Card
                Text("Code Example", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                CodeSnippetCard(
                    code = lesson.codeExample,
                    language = lesson.codeLanguage
                )

                // Interactive Code Playground Sandbox
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Terminal, contentDescription = null, tint = CyanPrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Interactive Code Sandbox", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }

                            Button(
                                onClick = { viewModel.runCode() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("run_lesson_code_button")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Run Code", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Code input box
                        OutlinedTextField(
                            value = uiState.userCode,
                            onValueChange = { viewModel.updateUserCode(it) },
                            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 120.dp)
                                .testTag("lesson_code_editor")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Console Terminal Output
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CodeBackground,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Terminal Console:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF8B949E),
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = uiState.consoleOutput,
                                    fontSize = 12.sp,
                                    color = if (uiState.consoleOutput.contains("✓")) EmeraldSuccess else Color.White,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                // Try It Yourself & Solution Toggle
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = IndigoAccent.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth().border(1.dp, IndigoAccent.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Code, contentDescription = null, tint = IndigoAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Try It Yourself Challenge", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = IndigoAccent)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(lesson.tryItYourselfPrompt, fontSize = 13.sp)

                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(onClick = { showSolution = !showSolution }) {
                            Text(if (showSolution) "Hide Solution" else "Reveal Solution →", color = IndigoAccent, fontWeight = FontWeight.Bold)
                        }

                        AnimatedVisibility(visible = showSolution) {
                            CodeSnippetCard(
                                code = lesson.tryItYourselfSolution,
                                language = lesson.codeLanguage
                            )
                        }
                    }
                }

                // Common Mistakes & Pro Tips
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Warning, contentDescription = null, tint = AmberWarning)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Common Mistakes & Pro Tips", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(lesson.commonMistakes, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }

                // Mini Practice Quiz
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Quiz, contentDescription = null, tint = CyanPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Mini Practice Quiz", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(lesson.miniQuizQuestion, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)

                        Spacer(modifier = Modifier.height(10.dp))

                        val options = lesson.miniQuizOptions.split("|")
                        options.forEachIndexed { index, option ->
                            val isSelected = uiState.selectedMiniQuizOption == index
                            val isSubmitted = uiState.isMiniQuizSubmitted
                            val isCorrectOption = index == lesson.miniQuizAnswerIndex

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = when {
                                    isSubmitted && isCorrectOption -> EmeraldSuccess.copy(alpha = 0.2f)
                                    isSubmitted && isSelected && !isCorrectOption -> MaterialTheme.colorScheme.errorContainer
                                    isSelected -> CyanPrimary.copy(alpha = 0.15f)
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable { viewModel.selectMiniQuizOption(index) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { viewModel.selectMiniQuizOption(index) }
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(option, fontSize = 13.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (!uiState.isMiniQuizSubmitted) {
                            Button(
                                onClick = { viewModel.submitMiniQuiz() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Check Answer")
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (uiState.isMiniQuizCorrect) EmeraldSuccess.copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = if (uiState.isMiniQuizCorrect) "✓ Correct! Well done!" else "✗ Not quite right.",
                                        fontWeight = FontWeight.Bold,
                                        color = if (uiState.isMiniQuizCorrect) EmeraldSuccess else MaterialTheme.colorScheme.error
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(lesson.miniQuizExplanation, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                // Personal Notes Section
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.EditNote, contentDescription = null, tint = CyanPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("My Personal Notes", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Button(
                                onClick = { viewModel.saveNote(currentUid, noteInput) },
                                colors = ButtonDefaults.buttonColors(containerColor = IndigoAccent),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("Save Note", fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = noteInput,
                            onValueChange = { noteInput = it },
                            placeholder = { Text("Write your key takeaways here...") },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 80.dp),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // Lesson Completion Celebration Modal
    if (showCompletionDialog) {
        AlertDialog(
            onDismissRequest = { showCompletionDialog = false },
            title = { Text("🎉 Lesson Completed!", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("You've mastered '${lesson?.title}'!")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("🏆 +${lesson?.xpReward} XP Earned", fontWeight = FontWeight.Bold, color = CyanPrimary)
                    Text("🪙 +${lesson?.coinReward} Coins Added", fontWeight = FontWeight.Bold, color = AmberWarning)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCompletionDialog = false
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary)
                ) {
                    Text("Continue Learning")
                }
            }
        )
    }
}
