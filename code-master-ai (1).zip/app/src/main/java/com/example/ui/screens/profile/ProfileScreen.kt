package com.example.ui.screens.profile

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CertificateEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.ProfileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    profileViewModel: ProfileViewModel,
    authViewModel: AuthViewModel,
    currentUid: String,
    onOpenSettings: () -> Unit,
    onOpenLesson: (String) -> Unit
) {
    val uiState by profileViewModel.uiState.collectAsState()
    val user = uiState.user

    LaunchedEffect(currentUid) {
        profileViewModel.loadProfileData(currentUid)
    }

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Certificates", "Achievements", "Bookmarks", "Notes", "Verify ID")

    var verifyCertInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Profile", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Outlined.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Card Header
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    listOf(IndigoAccent.copy(alpha = 0.15f), CyanPrimary.copy(alpha = 0.1f))
                                )
                            )
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Avatar Icon
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(CyanPrimary, IndigoAccent))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = user?.fullName?.take(2)?.uppercase() ?: "CM",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = user?.fullName ?: "Dedicated Learner",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = user?.email ?: "student@codemaster.ai",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Stats counters: Level, XP, Coins, Streak
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Level", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${user?.level ?: 1}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = IndigoAccent)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("XP", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${user?.xp ?: 0}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CyanPrimary)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Coins", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${user?.coins ?: 0}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AmberWarning)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Streak", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${user?.streak ?: 1}d", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AmberWarning)
                            }
                        }
                    }
                }
            }

            // Tab Row
            item {
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                    edgePadding = 8.dp
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        )
                    }
                }
            }

            // Tab 0: Certificates
            if (selectedTab == 0) {
                if (uiState.certificates.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Outlined.WorkspacePremium, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("No Certificates Earned Yet", fontWeight = FontWeight.Bold)
                                Text("Complete 100% of a course and its project to earn your verified certificate!", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                } else {
                    items(uiState.certificates) { cert ->
                        CertificateItemCard(cert)
                    }
                }
            }

            // Tab 1: Achievements
            if (selectedTab == 1) {
                items(uiState.achievements) { ach ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (ach.isUnlocked) EmeraldSuccess.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (ach.isUnlocked) EmeraldSuccess else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        if (ach.isUnlocked) Icons.Default.EmojiEvents else Icons.Outlined.Lock,
                                        contentDescription = null,
                                        tint = if (ach.isUnlocked) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(ach.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(ach.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            if (ach.isUnlocked) {
                                Surface(shape = RoundedCornerShape(6.dp), color = EmeraldSuccess.copy(alpha = 0.2f)) {
                                    Text("Unlocked", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Tab 2: Bookmarks
            if (selectedTab == 2) {
                if (uiState.bookmarks.isEmpty()) {
                    item {
                        Text("No bookmarked lessons yet. Tap the bookmark icon on any lesson to save it here!", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    items(uiState.bookmarks) { bm ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().clickable { onOpenLesson(bm.lessonId) }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(bm.lessonTitle, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(bm.courseTitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Icon(Icons.Default.ArrowForwardIos, contentDescription = null, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            // Tab 3: Notes
            if (selectedTab == 3) {
                if (uiState.notes.isEmpty()) {
                    item {
                        Text("No personal notes saved yet. Write notes inside lesson screens to review them anytime!", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    items(uiState.notes) { note ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(note.lessonTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CyanPrimary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(note.noteContent, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            // Tab 4: Verify Certificate ID
            if (selectedTab == 4) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Certificate Verification Portal", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Enter any 13-character Certificate ID (e.g. CM-2026-89421) to verify its authenticity.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = verifyCertInput,
                                onValueChange = { verifyCertInput = it },
                                label = { Text("Certificate ID (e.g. CM-2026-89421)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("cert_verify_input")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = { profileViewModel.verifyCertificateById(verifyCertInput) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().testTag("cert_verify_button")
                            ) {
                                Text("Verify Certificate Authenticity", fontWeight = FontWeight.Bold)
                            }

                            if (uiState.certSearchError != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(uiState.certSearchError ?: "", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                            }

                            val found = uiState.searchedCertificate
                            if (found != null) {
                                Spacer(modifier = Modifier.height(14.dp))
                                CertificateItemCard(found)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CertificateItemCard(cert: CertificateEntity) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AmberWarning.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("VERIFIED CERTIFICATE", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberWarning)
                }

                Surface(shape = RoundedCornerShape(4.dp), color = EmeraldSuccess.copy(alpha = 0.2f)) {
                    Text("✓ Authentic", fontSize = 10.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("This certifies that", fontSize = 11.sp, color = Color(0xFF94A3B8))
            Text(cert.studentName, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)

            Spacer(modifier = Modifier.height(4.dp))

            Text("has successfully completed the course", fontSize = 11.sp, color = Color(0xFF94A3B8))
            Text(cert.courseName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CyanPrimary)

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Issued On: ${cert.issueDate}", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Text("Grade: ${cert.grade}", fontSize = 11.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                    Text("Verified By: ${cert.verifiedBy}", fontSize = 11.sp, color = Color(0xFF94A3B8))
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("ID: ${cert.certificateId}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
                    Text("QR: VALID", fontSize = 10.sp, color = AmberWarning)
                }
            }
        }
    }
}
