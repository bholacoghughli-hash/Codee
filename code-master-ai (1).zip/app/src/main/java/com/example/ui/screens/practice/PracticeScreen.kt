package com.example.ui.screens.practice

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CodeSnippetCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.PracticeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PracticeScreen(
    viewModel: PracticeViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val questions = uiState.questions
    val currentQ = questions.getOrNull(uiState.currentIndex)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Practice & Mastery", fontWeight = FontWeight.Bold) },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AmberWarning.copy(alpha = 0.15f),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Stars, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Score: ${uiState.score}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AmberWarning)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        if (uiState.isFinished) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.padding(24.dp).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(60.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Practice Completed!", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Final Score: ${uiState.score} points", fontSize = 16.sp, color = CyanPrimary, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.loadPracticeSet("General", "Easy") },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Practice Again")
                        }
                    }
                }
            }
        } else if (currentQ != null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Progress counter
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Question ${uiState.currentIndex + 1} of ${questions.size}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = IndigoAccent.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = currentQ.type.replace("_", " ").uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = IndigoAccent,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                LinearProgressIndicator(
                    progress = { (uiState.currentIndex + 1).toFloat() / questions.size },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = CyanPrimary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                // Question Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(currentQ.question, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        if (currentQ.codeSnippet != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            CodeSnippetCard(
                                code = currentQ.codeSnippet,
                                language = "code"
                            )
                        }
                    }
                }

                // Options List
                currentQ.options.forEachIndexed { index, option ->
                    val isSelected = uiState.selectedOptionIndex == index
                    val isSubmitted = uiState.isSubmitted
                    val isCorrect = index == currentQ.correctIndex

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = when {
                                isSubmitted && isCorrect -> EmeraldSuccess.copy(alpha = 0.2f)
                                isSubmitted && isSelected && !isCorrect -> MaterialTheme.colorScheme.errorContainer
                                isSelected -> CyanPrimary.copy(alpha = 0.15f)
                                else -> MaterialTheme.colorScheme.surface
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (isSelected) CyanPrimary else MaterialTheme.colorScheme.outlineVariant,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.selectOption(index) }
                            .testTag("practice_option_$index")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { viewModel.selectOption(index) }
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(option, fontSize = 14.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }

                // Hint Ladder Section
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AmberWarning.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth().border(1.dp, AmberWarning.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.HelpOutline, contentDescription = null, tint = AmberWarning)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Step-by-Step Hints", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AmberWarning)
                            }
                            if (uiState.hintLevel < currentQ.hints.size) {
                                TextButton(onClick = { viewModel.revealNextHint() }) {
                                    Text("Reveal Hint ${uiState.hintLevel + 1}", fontSize = 12.sp, color = AmberWarning, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        if (uiState.hintLevel > 0) {
                            currentQ.hints.take(uiState.hintLevel).forEachIndexed { hIndex, hint ->
                                Text("💡 Hint ${hIndex + 1}: $hint", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }

                // Feedback & Explanation Banner
                AnimatedVisibility(visible = uiState.isSubmitted) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (uiState.isCorrect) EmeraldSuccess.copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = if (uiState.isCorrect) "✓ Correct (+25 pts)!" else "✗ Incorrect",
                                fontWeight = FontWeight.Bold,
                                color = if (uiState.isCorrect) EmeraldSuccess else MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(currentQ.explanation, fontSize = 13.sp)
                        }
                    }
                }

                // Action Buttons (Submit / Next)
                if (!uiState.isSubmitted) {
                    Button(
                        onClick = { viewModel.submitAnswer() },
                        enabled = uiState.selectedOptionIndex != null,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("practice_submit_button")
                    ) {
                        Text("Check Answer", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = { viewModel.nextQuestion() },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoAccent),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("practice_next_button")
                    ) {
                        Text("Next Question →", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
