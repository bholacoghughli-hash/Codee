package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AiTutorRepository
import com.example.data.repository.ChatMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class AiUiState(
    val messages: List<ChatMessage> = listOf(
        ChatMessage(
            id = "intro",
            sender = "ai",
            message = "👋 Hello! I am your **Code Master AI Tutor** created by developer Bhaskar. Ask me to explain concepts, debug code, write test cases, optimize algorithms, or create a personalized learning roadmap!"
        )
    ),
    val isGenerating: Boolean = false,
    val selectedTool: String = "tutor", // tutor, explainer, debugger, optimizer, roadmap
    val toolInputCode: String = "",
    val toolLanguage: String = "Python",
    val toolOutputResult: String? = null,
    val errorMessage: String? = null
)

class AiViewModel(private val aiRepository: AiTutorRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(AiUiState())
    val uiState: StateFlow<AiUiState> = _uiState.asStateFlow()

    fun selectTool(tool: String) {
        _uiState.update { it.copy(selectedTool = tool, toolOutputResult = null, errorMessage = null) }
    }

    fun updateToolInput(text: String) {
        _uiState.update { it.copy(toolInputCode = text) }
    }

    fun updateToolLanguage(lang: String) {
        _uiState.update { it.copy(toolLanguage = lang) }
    }

    fun sendMessage(prompt: String) {
        if (prompt.isBlank()) return
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = "user",
            message = prompt
        )
        _uiState.update {
            it.copy(
                messages = it.messages + userMsg,
                isGenerating = true,
                errorMessage = null
            )
        }

        viewModelScope.launch {
            try {
                val aiResponse = aiRepository.askAiTutor(prompt)
                val aiMsg = ChatMessage(
                    id = UUID.randomUUID().toString(),
                    sender = "ai",
                    message = aiResponse
                )
                _uiState.update {
                    it.copy(
                        messages = it.messages + aiMsg,
                        isGenerating = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        errorMessage = "AI temporarily unavailable. Please tap retry."
                    )
                }
            }
        }
    }

    fun runSelectedTool() {
        val current = _uiState.value
        val input = current.toolInputCode.ifBlank {
            when (current.selectedTool) {
                "explainer" -> "def fibonacci(n):\n    return n if n <= 1 else fibonacci(n-1) + fibonacci(n-2)"
                "debugger" -> "for i in range(5)\n    print(i"
                "optimizer" -> "def find_duplicates(arr):\n    dup = []\n    for i in arr:\n        if arr.count(i) > 1 and i not in dup:\n            dup.append(i)\n    return dup"
                "roadmap" -> "Full Stack Web & Android Mobile Developer"
                else -> "Explain Variables"
            }
        }

        _uiState.update { it.copy(isGenerating = true, errorMessage = null, toolOutputResult = null) }

        viewModelScope.launch {
            try {
                val result = when (current.selectedTool) {
                    "explainer" -> aiRepository.explainCode(input, current.toolLanguage, simplify = false)
                    "debugger" -> aiRepository.findBugsAndFix(input, current.toolLanguage)
                    "optimizer" -> aiRepository.optimizeCode(input, current.toolLanguage)
                    "roadmap" -> aiRepository.generateRoadmap(input, "Beginner")
                    else -> aiRepository.askAiTutor(input)
                }
                _uiState.update { it.copy(isGenerating = false, toolOutputResult = result) }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        errorMessage = "Failed to run AI tool. Please check connection and try again."
                    )
                }
            }
        }
    }
}
