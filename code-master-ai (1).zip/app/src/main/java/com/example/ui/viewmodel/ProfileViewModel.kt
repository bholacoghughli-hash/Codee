package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.*
import com.example.data.repository.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ProfileUiState(
    val user: UserEntity? = null,
    val certificates: List<CertificateEntity> = emptyList(),
    val achievements: List<AchievementEntity> = emptyList(),
    val bookmarks: List<BookmarkEntity> = emptyList(),
    val notes: List<NoteEntity> = emptyList(),
    val searchedCertificate: CertificateEntity? = null,
    val isSearchingCert: Boolean = false,
    val certSearchError: String? = null
)

class ProfileViewModel(
    private val authRepository: AuthRepository,
    private val progressRepository: ProgressRepository,
    private val communityAndNoteRepository: CommunityAndNoteRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    fun loadProfileData(uid: String) {
        viewModelScope.launch {
            authRepository.getCurrentUserFlow().collect { user ->
                _uiState.update { it.copy(user = user) }
            }
        }
        viewModelScope.launch {
            progressRepository.getCertificatesForUserFlow(uid).collect { certs ->
                _uiState.update { it.copy(certificates = certs) }
            }
        }
        viewModelScope.launch {
            progressRepository.getAllAchievementsFlow().collect { achs ->
                _uiState.update { it.copy(achievements = achs) }
            }
        }
        viewModelScope.launch {
            communityAndNoteRepository.getBookmarksForUserFlow(uid).collect { bms ->
                _uiState.update { it.copy(bookmarks = bms) }
            }
        }
        viewModelScope.launch {
            communityAndNoteRepository.getNotesForUserFlow(uid).collect { notes ->
                _uiState.update { it.copy(notes = notes) }
            }
        }
    }

    fun verifyCertificateById(certId: String) {
        val cleanId = certId.trim().uppercase()
        if (cleanId.isBlank()) {
            _uiState.update { it.copy(certSearchError = "Please enter a Certificate ID") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSearchingCert = true, certSearchError = null, searchedCertificate = null) }
            val cert = progressRepository.getCertificateById(cleanId)
            if (cert != null) {
                _uiState.update { it.copy(isSearchingCert = false, searchedCertificate = cert) }
            } else {
                _uiState.update {
                    it.copy(
                        isSearchingCert = false,
                        certSearchError = "No verified certificate found with ID '$cleanId'. Please verify the ID."
                    )
                }
            }
        }
    }

    fun clearCertSearch() {
        _uiState.update { it.copy(searchedCertificate = null, certSearchError = null) }
    }
}
