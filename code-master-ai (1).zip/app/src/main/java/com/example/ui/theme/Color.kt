package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Code Master AI Palette
val CyanPrimary = Color(0xFF06B6D4)
val CyanPrimaryDark = Color(0xFF0891B2)
val CyanLight = Color(0xFF67E8F9)

val IndigoAccent = Color(0xFF6366F1)
val VioletAccent = Color(0xFF8B5CF6)
val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFEF4444)

// Dark Theme Colors
val DarkBackground = Color(0xFF0A0E1A)
val DarkSurface = Color(0xFF121829)
val DarkSurfaceVariant = Color(0xFF1E2638)
val DarkCard = Color(0xFF161F33)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF2E3B55)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightCard = Color(0xFFFFFFFF)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
val LightBorder = Color(0xFFE2E8F0)

// Code Syntax Colors
val CodeBackground = Color(0xFF0D1117)
val CodeKeyword = Color(0xFFFF7B72)
val CodeString = Color(0xFFA5D6FF)
val CodeFunction = Color(0xFFD2A8FF)
val CodeComment = Color(0xFF8B949E)
val CodeNumber = Color(0xFF79C0FF)
