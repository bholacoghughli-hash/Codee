package com.example.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.data.local.CodeMasterDatabase
import com.example.data.repository.*
import com.example.ui.screens.admin.AdminScreen
import com.example.ui.screens.ai.AiTutorScreen
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.community.CommunityScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.learn.LearnScreen
import com.example.ui.screens.lesson.LessonScreen
import com.example.ui.screens.playground.PlaygroundScreen
import com.example.ui.screens.practice.PracticeScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.theme.CyanPrimary
import com.example.ui.viewmodel.*

sealed class BottomNavItem(val route: String, val title: String, val icon: ImageVector, val selectedIcon: ImageVector) {
    object Home : BottomNavItem("home", "Home", Icons.Outlined.Home, Icons.Filled.Home)
    object Learn : BottomNavItem("learn", "Learn", Icons.Outlined.School, Icons.Filled.School)
    object Practice : BottomNavItem("practice", "Practice", Icons.Outlined.Quiz, Icons.Filled.Quiz)
    object Playground : BottomNavItem("playground", "Code", Icons.Outlined.Code, Icons.Filled.Code)
    object AiTutor : BottomNavItem("ai_tutor", "AI Tutor", Icons.Outlined.AutoAwesome, Icons.Filled.AutoAwesome)
    object Community : BottomNavItem("community", "Discuss", Icons.Outlined.Forum, Icons.Filled.Forum)
    object Profile : BottomNavItem("profile", "Profile", Icons.Outlined.Person, Icons.Filled.Person)
}

@Composable
fun MainApp(database: CodeMasterDatabase) {
    val navController = rememberNavController()

    // Initialize Repositories
    val authRepository = remember { AuthRepository(database.userDao()) }
    val courseRepository = remember { CourseRepository(database.courseDao()) }
    val progressRepository = remember { ProgressRepository(database.progressDao(), database.userDao(), database.certificateDao(), database.achievementDao()) }
    val practiceRepository = remember { PracticeAndQuizRepository(database.quizDao(), database.projectDao(), database.dailyChallengeDao(), database.userDao()) }
    val communityRepository = remember { CommunityAndNoteRepository(database.communityDao(), database.noteDao(), database.bookmarkDao(), database.playgroundDao()) }
    val aiRepository = remember { AiTutorRepository() }

    // ViewModels
    val authViewModel = remember { AuthViewModel(authRepository) }
    val homeViewModel = remember { HomeViewModel(authRepository, courseRepository, progressRepository, practiceRepository) }
    val learnViewModel = remember { LearnViewModel(courseRepository, progressRepository) }
    val lessonViewModel = remember { LessonViewModel(courseRepository, progressRepository, communityRepository, aiRepository) }
    val practiceViewModel = remember { PracticeViewModel(practiceRepository) }
    val playgroundViewModel = remember { PlaygroundViewModel(communityRepository) }
    val aiViewModel = remember { AiViewModel(aiRepository) }
    val adminViewModel = remember { AdminViewModel(authRepository, courseRepository, progressRepository) }
    val profileViewModel = remember { ProfileViewModel(authRepository, progressRepository, communityRepository) }

    val currentUser by authViewModel.currentUser.collectAsState()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomNavItems = listOf(
        BottomNavItem.Home,
        BottomNavItem.Learn,
        BottomNavItem.Practice,
        BottomNavItem.Playground,
        BottomNavItem.AiTutor,
        BottomNavItem.Community,
        BottomNavItem.Profile
    )

    val showBottomBar = bottomNavItems.any { it.route == currentRoute }

    Scaffold(
        bottomBar = {
            if (showBottomBar && currentUser != null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    bottomNavItems.forEach { item ->
                        val isSelected = currentRoute == item.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.icon,
                                    contentDescription = item.title,
                                    modifier = Modifier.size(20.dp),
                                    tint = if (isSelected) CyanPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    fontSize = 10.sp,
                                    color = if (isSelected) CyanPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            modifier = Modifier.testTag("nav_item_${item.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = if (currentUser == null) "auth" else "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            // Auth Destination
            composable("auth") {
                AuthScreen(
                    viewModel = authViewModel,
                    onAuthSuccess = {
                        navController.navigate("home") {
                            popUpTo("auth") { inclusive = true }
                        }
                    }
                )
            }

            // Bottom Nav Destinations
            composable(BottomNavItem.Home.route) {
                HomeScreen(
                    viewModel = homeViewModel,
                    onCourseClick = { courseId ->
                        learnViewModel.selectCourse(courseId, currentUser?.uid ?: "student_demo_01")
                        navController.navigate("learn")
                    },
                    onOpenAiTutor = { navController.navigate("ai_tutor") },
                    onOpenPlayground = { navController.navigate("playground") },
                    onOpenAdmin = { navController.navigate("admin") },
                    onOpenProfile = { navController.navigate("profile") }
                )
            }

            composable(BottomNavItem.Learn.route) {
                LearnScreen(
                    viewModel = learnViewModel,
                    currentUid = currentUser?.uid ?: "student_demo_01",
                    onOpenLesson = { lessonId ->
                        navController.navigate("lesson/$lessonId")
                    }
                )
            }

            composable(BottomNavItem.Practice.route) {
                PracticeScreen(viewModel = practiceViewModel)
            }

            composable(BottomNavItem.Playground.route) {
                PlaygroundScreen(
                    viewModel = playgroundViewModel,
                    currentUid = currentUser?.uid ?: "student_demo_01",
                    onOpenAiTutor = { navController.navigate("ai_tutor") }
                )
            }

            composable(BottomNavItem.AiTutor.route) {
                AiTutorScreen(
                    viewModel = aiViewModel,
                    onBack = null
                )
            }

            composable(BottomNavItem.Community.route) {
                CommunityScreen(
                    repository = communityRepository,
                    currentUid = currentUser?.uid ?: "student_demo_01",
                    currentUserName = currentUser?.fullName ?: "Learner",
                    currentUserRole = currentUser?.role ?: "student"
                )
            }

            composable(BottomNavItem.Profile.route) {
                ProfileScreen(
                    profileViewModel = profileViewModel,
                    authViewModel = authViewModel,
                    currentUid = currentUser?.uid ?: "student_demo_01",
                    onOpenSettings = { navController.navigate("settings") },
                    onOpenLesson = { lessonId ->
                        navController.navigate("lesson/$lessonId")
                    }
                )
            }

            // Standalone Screens
            composable(
                route = "lesson/{lessonId}",
                arguments = listOf(navArgument("lessonId") { type = NavType.StringType })
            ) { backStackEntry ->
                val lessonId = backStackEntry.arguments?.getString("lessonId") ?: "les_py_1"
                LessonScreen(
                    viewModel = lessonViewModel,
                    lessonId = lessonId,
                    currentUid = currentUser?.uid ?: "student_demo_01",
                    onBack = { navController.popBackStack() },
                    onOpenAiTutor = { navController.navigate("ai_tutor") }
                )
            }

            composable("admin") {
                AdminScreen(
                    viewModel = adminViewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("settings") {
                SettingsScreen(
                    authViewModel = authViewModel,
                    user = currentUser,
                    onBack = { navController.popBackStack() },
                    onLoggedOut = {
                        navController.navigate("auth") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                )
            }
        }
    }
}
