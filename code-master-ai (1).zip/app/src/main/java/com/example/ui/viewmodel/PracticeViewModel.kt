package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.PracticeAndQuizRepository
import com.example.data.repository.PracticeQuestion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PracticeUiState(
    val questions: List<PracticeQuestion> = emptyList(),
    val currentIndex: Int = 0,
    val selectedOptionIndex: Int? = null,
    val isSubmitted: Boolean = false,
    val isCorrect: Boolean = false,
    val hintLevel: Int = 0, // 0 = no hints, 1 = hint 1, 2 = hint 2, 3 = full explanation
    val score: Int = 0,
    val isFinished: Boolean = false,
    val isFlashcardFlipped: Boolean = false
)

class PracticeViewModel(
    private val practiceRepository: PracticeAndQuizRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PracticeUiState())
    val uiState: StateFlow<PracticeUiState> = _uiState.asStateFlow()

    init {
        loadPracticeSet("General", "Easy")
    }

    fun loadPracticeSet(category: String, difficulty: String) {
        val list = practiceRepository.getPracticeSet(category, difficulty)
        _uiState.update {
            PracticeUiState(
                questions = list,
                currentIndex = 0,
                score = 0,
                isFinished = false
            )
        }
    }

    fun selectOption(index: Int) {
        if (!_uiState.value.isSubmitted) {
            _uiState.update { it.copy(selectedOptionIndex = index) }
        }
    }

    fun submitAnswer() {
        val state = _uiState.value
        val currentQ = state.questions.getOrNull(state.currentIndex) ?: return
        val isCorrect = state.selectedOptionIndex == currentQ.correctIndex
        val newScore = if (isCorrect) state.score + 25 else state.score

        _uiState.update {
            it.copy(
                isSubmitted = true,
                isCorrect = isCorrect,
                score = newScore
            )
        }
    }

    fun nextQuestion() {
        val state = _uiState.value
        if (state.currentIndex + 1 < state.questions.size) {
            _uiState.update {
                it.copy(
                    currentIndex = it.currentIndex + 1,
                    selectedOptionIndex = null,
                    isSubmitted = false,
                    isCorrect = false,
                    hintLevel = 0,
                    isFlashcardFlipped = false
                )
            }
        } else {
            _uiState.update { it.copy(isFinished = true) }
        }
    }

    fun revealNextHint() {
        _uiState.update { it.copy(hintLevel = (it.hintLevel + 1).coerceAtMost(3)) }
    }

    fun toggleFlashcardFlip() {
        _uiState.update { it.copy(isFlashcardFlipped = !it.isFlashcardFlipped) }
    }
}
