package com.example.ui.screens.community

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CommunityPostEntity
import com.example.data.repository.CommunityAndNoteRepository
import com.example.ui.components.CodeSnippetCard
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunityScreen(
    repository: CommunityAndNoteRepository,
    currentUid: String,
    currentUserName: String,
    currentUserRole: String
) {
    val coroutineScope = rememberCoroutineScope()
    val posts by repository.getAllPostsFlow().collectAsState(initial = emptyList())

    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Questions", "Tips", "Projects")

    var showNewPostDialog by remember { mutableStateOf(false) }
    var postTitle by remember { mutableStateOf("") }
    var postContent by remember { mutableStateOf("") }
    var postCode by remember { mutableStateOf("") }
    var postCat by remember { mutableStateOf("Question") }

    val filteredPosts = posts.filter { post ->
        if (selectedFilter == "All") true
        else if (selectedFilter == "Questions") post.category.equals("Question", ignoreCase = true)
        else if (selectedFilter == "Tips") post.category.equals("Tip", ignoreCase = true)
        else post.category.equals("Project", ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Learner Community & Q&A", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showNewPostDialog = true }) {
                        Icon(Icons.Default.AddComment, contentDescription = "New Post", tint = CyanPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewPostDialog = true },
                containerColor = CyanPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("new_post_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ask Question")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Category Filter
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filters.forEach { filter ->
                    val isSelected = filter == selectedFilter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredPosts) { post ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Author Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(if (post.authorRole == "admin") IndigoAccent else CyanPrimary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = post.authorName.take(1).uppercase(),
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(post.authorName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        if (post.authorRole == "admin") {
                                            Text("Admin • Lead Architect", fontSize = 10.sp, color = IndigoAccent, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        text = post.category,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(post.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(post.content, fontSize = 13.sp, lineHeight = 19.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            if (post.codeSnippet.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                CodeSnippetCard(
                                    code = post.codeSnippet,
                                    language = post.language.ifBlank { "code" }
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Interactions (Likes, Answers, Report)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.clickable {
                                            coroutineScope.launch { repository.likePost(post.postId) }
                                        }
                                    ) {
                                        Icon(Icons.Outlined.ThumbUp, contentDescription = "Like", modifier = Modifier.size(16.dp), tint = CyanPrimary)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("${post.likesCount}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = "Replies", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("${post.answersCount}", fontSize = 12.sp)
                                    }
                                }

                                IconButton(
                                    onClick = { coroutineScope.launch { repository.reportPost(post.postId) } },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Outlined.Flag, contentDescription = "Report", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // New Post Dialog
    if (showNewPostDialog) {
        AlertDialog(
            onDismissRequest = { showNewPostDialog = false },
            title = { Text("Ask Question or Share Tip") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = postTitle, onValueChange = { postTitle = it }, label = { Text("Topic Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = postContent, onValueChange = { postContent = it }, label = { Text("Detailed Question or Insight") }, modifier = Modifier.fillMaxWidth().heightIn(min = 70.dp))
                    OutlinedTextField(value = postCode, onValueChange = { postCode = it }, label = { Text("Optional Code Snippet") }, modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp))
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (postTitle.isNotBlank() && postContent.isNotBlank()) {
                            coroutineScope.launch {
                                repository.createPost(
                                    authorUid = currentUid,
                                    authorName = currentUserName,
                                    authorRole = currentUserRole,
                                    title = postTitle,
                                    content = postContent,
                                    category = postCat,
                                    codeSnippet = postCode
                                )
                                showNewPostDialog = false
                                postTitle = ""
                                postContent = ""
                                postCode = ""
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary)
                ) {
                    Text("Post to Community")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewPostDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
