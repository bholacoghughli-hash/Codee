package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.LessonEntity
import com.example.data.repository.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class LessonUiState(
    val lesson: LessonEntity? = null,
    val isEasyModeEnabled: Boolean = false,
    val selectedLanguage: String = "English", // English, Hindi, Hinglish
    val isBookmarked: Boolean = false,
    val userCode: String = "",
    val consoleOutput: String = "",
    val isRunningCode: Boolean = false,
    val selectedMiniQuizOption: Int? = null,
    val isMiniQuizSubmitted: Boolean = false,
    val isMiniQuizCorrect: Boolean = false,
    val isLessonCompleted: Boolean = false,
    val noteText: String = "",
    val isNoteSaved: Boolean = false,
    val isTtsPlaying: Boolean = false,
    val totalLessonsInCourse: Int = 9
)

class LessonViewModel(
    private val courseRepository: CourseRepository,
    private val progressRepository: ProgressRepository,
    private val communityAndNoteRepository: CommunityAndNoteRepository,
    private val aiTutorRepository: AiTutorRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LessonUiState())
    val uiState: StateFlow<LessonUiState> = _uiState.asStateFlow()

    fun loadLesson(lessonId: String, currentUid: String) {
        viewModelScope.launch {
            val lesson = courseRepository.getLessonById(lessonId)
            if (lesson != null) {
                _uiState.update {
                    it.copy(
                        lesson = lesson,
                        userCode = lesson.tryItYourselfStarterCode.ifBlank { lesson.codeExample },
                        consoleOutput = "Ready to run code..."
                    )
                }

                // Check bookmark
                communityAndNoteRepository.isBookmarkedFlow(currentUid, lessonId).collect { bookmarked ->
                    _uiState.update { it.copy(isBookmarked = bookmarked) }
                }
            }
        }
        viewModelScope.launch {
            communityAndNoteRepository.getNoteForLessonFlow(currentUid, lessonId).collect { note ->
                _uiState.update { it.copy(noteText = note?.noteContent ?: "") }
            }
        }
    }

    fun toggleEasyMode() {
        _uiState.update { it.copy(isEasyModeEnabled = !it.isEasyModeEnabled) }
    }

    fun setLanguage(lang: String) {
        _uiState.update { it.copy(selectedLanguage = lang) }
    }

    fun updateUserCode(code: String) {
        _uiState.update { it.copy(userCode = code) }
    }

    fun runCode() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRunningCode = true, consoleOutput = "⚡ Compiling & Executing...") }
            kotlinx.coroutines.delay(400)
            val lesson = _uiState.value.lesson
            val code = _uiState.value.userCode
            val simulatedOutput = if (lesson != null && code.contains(lesson.tryItYourselfSolution.take(10))) {
                "✓ Execution Successful!\n" + lesson.expectedOutput
            } else {
                "▶ Output (Code Master Sandbox):\n" + (lesson?.expectedOutput ?: "Hello from Code Master AI!\nProcess finished with exit code 0")
            }
            _uiState.update { it.copy(isRunningCode = false, consoleOutput = simulatedOutput) }
        }
    }

    fun selectMiniQuizOption(index: Int) {
        if (!_uiState.value.isMiniQuizSubmitted) {
            _uiState.update { it.copy(selectedMiniQuizOption = index) }
        }
    }

    fun submitMiniQuiz() {
        val current = _uiState.value
        val lesson = current.lesson ?: return
        val isCorrect = current.selectedMiniQuizOption == lesson.miniQuizAnswerIndex
        _uiState.update {
            it.copy(
                isMiniQuizSubmitted = true,
                isMiniQuizCorrect = isCorrect
            )
        }
    }

    fun toggleBookmark(uid: String) {
        viewModelScope.launch {
            val lesson = _uiState.value.lesson ?: return@launch
            communityAndNoteRepository.toggleBookmark(
                uid = uid,
                lessonId = lesson.lessonId,
                courseId = lesson.courseId,
                lessonTitle = lesson.title,
                courseTitle = "Course",
                isCurrentlyBookmarked = _uiState.value.isBookmarked
            )
        }
    }

    fun saveNote(uid: String, content: String) {
        viewModelScope.launch {
            val lesson = _uiState.value.lesson ?: return@launch
            communityAndNoteRepository.saveNote(uid, lesson.lessonId, lesson.title, content)
            _uiState.update { it.copy(noteText = content, isNoteSaved = true) }
        }
    }

    fun toggleTts() {
        _uiState.update { it.copy(isTtsPlaying = !it.isTtsPlaying) }
    }

    fun markLessonComplete(uid: String, onComplete: () -> Unit) {
        viewModelScope.launch {
            val lesson = _uiState.value.lesson ?: return@launch
            progressRepository.completeLesson(
                uid = uid,
                courseId = lesson.courseId,
                lessonId = lesson.lessonId,
                xpEarned = lesson.xpReward,
                coinsEarned = lesson.coinReward,
                totalLessonsInCourse = _uiState.value.totalLessonsInCourse
            )
            _uiState.update { it.copy(isLessonCompleted = true) }
            onComplete()
        }
    }
}
