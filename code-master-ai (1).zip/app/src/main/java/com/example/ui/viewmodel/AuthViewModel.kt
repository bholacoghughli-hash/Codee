package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.UserEntity
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AuthUiState(
    val currentUser: UserEntity? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val isOtpSent: Boolean = false,
    val otpCountdown: Int = 0,
    val isEmailVerificationSent: Boolean = false
)

class AuthViewModel(private val authRepository: AuthRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    val currentUser: StateFlow<UserEntity?> = authRepository.getCurrentUserFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        viewModelScope.launch {
            authRepository.getCurrentUserFlow().collect { user ->
                _uiState.update { it.copy(currentUser = user) }
            }
        }
    }

    fun login(email: String, pass: String, onSuccess: (UserEntity) -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = authRepository.loginWithEmail(email, pass)) {
                is AuthResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, currentUser = res.data, successMessage = "Welcome back, ${res.data.fullName}!") }
                    onSuccess(res.data)
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
            }
        }
    }

    fun register(
        fullName: String,
        email: String,
        phone: String,
        language: String,
        level: String,
        goal: String,
        country: String,
        onSuccess: (UserEntity) -> Unit
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = authRepository.registerStudent(fullName, email, phone, language, level, goal, country)) {
                is AuthResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, currentUser = res.data, successMessage = "Account created successfully!") }
                    onSuccess(res.data)
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
            }
        }
    }

    fun continueWithGoogle(onSuccess: (UserEntity) -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            // Real OAuth simulation
            delay(600)
            val res = authRepository.loginWithGoogle("student.google@codemaster.ai", "Google Learner")
            if (res is AuthResult.Success) {
                _uiState.update { it.copy(isLoading = false, currentUser = res.data) }
                onSuccess(res.data)
            }
        }
    }

    fun sendPhoneOtp(phone: String) {
        viewModelScope.launch {
            if (phone.length < 10) {
                _uiState.update { it.copy(errorMessage = "Please enter a valid 10-digit phone number.") }
                return@launch
            }
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            delay(500)
            _uiState.update { it.copy(isLoading = false, isOtpSent = true, otpCountdown = 60, successMessage = "OTP sent to $phone") }
            startOtpTimer()
        }
    }

    private fun startOtpTimer() {
        viewModelScope.launch {
            while (_uiState.value.otpCountdown > 0) {
                delay(1000)
                _uiState.update { it.copy(otpCountdown = it.otpCountdown - 1) }
            }
        }
    }

    fun verifyPhoneOtp(phone: String, otp: String, onSuccess: (UserEntity) -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = authRepository.verifyPhoneOtp(phone, otp)) {
                is AuthResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, currentUser = res.data, isOtpSent = false) }
                    onSuccess(res.data)
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
            }
        }
    }

    fun sendPasswordReset(email: String) {
        viewModelScope.launch {
            if (email.isBlank() || !email.contains("@")) {
                _uiState.update { it.copy(errorMessage = "Please enter a valid email for password reset.") }
                return@launch
            }
            _uiState.update { it.copy(isLoading = true) }
            delay(400)
            _uiState.update { it.copy(isLoading = false, successMessage = "Password reset instructions sent to $email.") }
        }
    }

    fun sendEmailVerification() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            delay(400)
            _uiState.update { it.copy(isLoading = false, isEmailVerificationSent = true, successMessage = "Verification email sent!") }
        }
    }

    fun switchToAdmin(onSuccess: (UserEntity) -> Unit) {
        viewModelScope.launch {
            val admin = authRepository.switchToAdminSession()
            if (admin != null) {
                _uiState.update { it.copy(currentUser = admin) }
                onSuccess(admin)
            }
        }
    }

    fun switchToStudent(onSuccess: (UserEntity) -> Unit) {
        viewModelScope.launch {
            val student = authRepository.switchToStudentSession()
            if (student != null) {
                _uiState.update { it.copy(currentUser = student) }
                onSuccess(student)
            }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }

    fun logout(onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            authRepository.logout()
            _uiState.update { AuthUiState() }
            onLoggedOut()
        }
    }

    fun deleteAccount(onDeleted: () -> Unit) {
        viewModelScope.launch {
            authRepository.deleteAccount()
            _uiState.update { AuthUiState() }
            onDeleted()
        }
    }
}
