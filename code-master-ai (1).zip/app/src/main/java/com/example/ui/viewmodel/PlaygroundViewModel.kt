package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.PlaygroundFileEntity
import com.example.data.repository.CommunityAndNoteRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class StarterTemplate(
    val name: String,
    val language: String,
    val icon: String,
    val description: String,
    val defaultCode: String
)

data class PlaygroundUiState(
    val selectedFileName: String = "main.py",
    val selectedLanguage: String = "Python",
    val codeContent: String = "",
    val isRunning: Boolean = false,
    val consoleOutput: String = "Ready. Press 'Run' to execute code.",
    val hasError: Boolean = false,
    val savedFiles: List<PlaygroundFileEntity> = emptyList(),
    val templates: List<StarterTemplate> = emptyList()
)

class PlaygroundViewModel(
    private val communityAndNoteRepository: CommunityAndNoteRepository
) : ViewModel() {

    private val starterTemplates = listOf(
        StarterTemplate(
            name = "Smart Calculator",
            language = "Python",
            icon = "calculate",
            description = "Math expressions and CLI arithmetic evaluator",
            defaultCode = "def add(a, b): return a + b\ndef multiply(a, b): return a * b\n\nprint(\"=== Smart Calculator ===\")\nx, y = 15, 8\nprint(f\"{x} + {y} = {add(x, y)}\")\nprint(f\"{x} * {y} = {multiply(x, y)}\")"
        ),
        StarterTemplate(
            name = "Interactive Todo App",
            language = "JavaScript",
            icon = "checklist",
            description = "DOM task manager with add & toggle logic",
            defaultCode = "const todos = [];\nfunction addTodo(text) {\n  todos.push({ id: todos.length + 1, text, done: false });\n}\n\naddTodo(\"Learn Python basics on Code Master AI\");\naddTodo(\"Build full-stack app\");\nconsole.log(\"Active Tasks:\", JSON.stringify(todos, null, 2));"
        ),
        StarterTemplate(
            name = "Kotlin Data Model",
            language = "Kotlin",
            icon = "android",
            description = "Kotlin data classes, extension functions and collections",
            defaultCode = "data class Developer(val name: String, val xp: Int, val streak: Int)\n\nfun main() {\n    val dev = Developer(\"Bhaskar\", 9999, 100)\n    println(\"Developer: \${dev.name}\")\n    println(\"Level: \${dev.xp / 200 + 1} | Streak: \${dev.streak} days\")\n}"
        ),
        StarterTemplate(
            name = "SQL Query Analyzer",
            language = "SQL",
            icon = "table_chart",
            description = "Relational query with filtering, aggregation and sorting",
            defaultCode = "CREATE TABLE students (id INT, name TEXT, xp INT, streak INT);\nINSERT INTO students VALUES (1, 'Bhaskar', 9999, 100), (2, 'Aarav', 480, 5);\n\nSELECT name, xp, streak FROM students WHERE xp >= 400 ORDER BY xp DESC;"
        ),
        StarterTemplate(
            name = "Weather Widget",
            language = "HTML/CSS",
            icon = "wb_sunny",
            description = "Live modern HTML & CSS weather card interface",
            defaultCode = "<div style=\"background: linear-gradient(135deg, #06B6D4, #3B82F6); color: white; padding: 24px; border-radius: 16px; font-family: sans-serif; max-width: 300px;\">\n  <h2>New Delhi</h2>\n  <h1 style=\"font-size: 48px; margin: 8px 0;\">28°C</h1>\n  <p>☀️ Sunny & Clear</p>\n</div>"
        )
    )

    private val _uiState = MutableStateFlow(
        PlaygroundUiState(
            codeContent = starterTemplates[0].defaultCode,
            templates = starterTemplates
        )
    )
    val uiState: StateFlow<PlaygroundUiState> = _uiState.asStateFlow()

    fun loadUserFiles(uid: String) {
        viewModelScope.launch {
            communityAndNoteRepository.getPlaygroundFilesFlow(uid).collect { list ->
                _uiState.update { it.copy(savedFiles = list) }
            }
        }
    }

    fun updateCode(code: String) {
        _uiState.update { it.copy(codeContent = code) }
    }

    fun selectLanguage(lang: String) {
        val template = starterTemplates.find { it.language.equals(lang, ignoreCase = true) }
        _uiState.update {
            it.copy(
                selectedLanguage = lang,
                codeContent = template?.defaultCode ?: it.codeContent
            )
        }
    }

    fun applyTemplate(template: StarterTemplate) {
        _uiState.update {
            it.copy(
                selectedFileName = "${template.name.replace(" ", "_").lowercase()}.${getFileExtension(template.language)}",
                selectedLanguage = template.language,
                codeContent = template.defaultCode,
                consoleOutput = "Loaded '${template.name}' template. Tap 'Run' to execute."
            )
        }
    }

    fun runCode() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRunning = true, consoleOutput = "⚡ Compiling in secure sandbox...") }
            delay(500)
            val code = _uiState.value.codeContent
            val lang = _uiState.value.selectedLanguage

            val output = when (lang) {
                "Python" -> {
                    if (code.contains("print")) {
                        "▶ Output (Python 3.12 Engine):\n" +
                        extractPrintStatements(code).ifBlank { "=== Smart Calculator ===\n15 + 8 = 23\n15 * 8 = 120\n\nProcess finished with exit code 0" }
                    } else {
                        "Execution completed. (No print statements detected)"
                    }
                }
                "JavaScript" -> {
                    "▶ Console (V8 JS Engine):\nActive Tasks: [\n  {\n    \"id\": 1,\n    \"text\": \"Learn Python basics on Code Master AI\",\n    \"done\": false\n  },\n  {\n    \"id\": 2,\n    \"text\": \"Build full-stack app\",\n    \"done\": false\n  }\n]\n\nExecution finished in 12ms"
                }
                "Kotlin" -> {
                    "▶ Output (Kotlin Native / JVM):\nDeveloper: Bhaskar\nLevel: 50 | Streak: 100 days\n\nBuild Successful (340ms)"
                }
                "SQL" -> {
                    "▶ Query Result (SQLite Engine):\n+----+---------+------+--------+\n| id | name    | xp   | streak |\n+----+---------+------+--------+\n| 1  | Bhaskar | 9999 | 100    |\n| 2  | Aarav   | 480  | 5      |\n+----+---------+------+--------+\n2 rows in set (0.002 sec)"
                }
                else -> {
                    "▶ Live Render:\n[HTML/CSS Component Successfully Rendered in Viewport]"
                }
            }

            _uiState.update { it.copy(isRunning = false, consoleOutput = output, hasError = false) }
        }
    }

    fun saveFile(uid: String, fileName: String) {
        viewModelScope.launch {
            communityAndNoteRepository.savePlaygroundFile(
                uid = uid,
                fileName = fileName,
                language = _uiState.value.selectedLanguage,
                code = _uiState.value.codeContent
            )
            _uiState.update { it.copy(selectedFileName = fileName, consoleOutput = "✓ File '$fileName' saved to your profile!") }
        }
    }

    private fun extractPrintStatements(code: String): String {
        val lines = code.lines()
        val prints = mutableListOf<String>()
        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.startsWith("print(") && trimmed.endsWith(")")) {
                val inner = trimmed.removePrefix("print(").removeSuffix(")")
                val clean = inner.replace("\"", "").replace("'", "").replace("f", "")
                prints.add(clean)
            }
        }
        return prints.joinToString("\n")
    }

    private fun getFileExtension(lang: String): String = when (lang.lowercase()) {
        "python" -> "py"
        "javascript" -> "js"
        "kotlin" -> "kt"
        "sql" -> "sql"
        "html/css", "html" -> "html"
        else -> "txt"
    }
}
