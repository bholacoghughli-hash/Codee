package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.*
import com.example.data.repository.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HomeUiState(
    val currentUser: UserEntity? = null,
    val inProgressCourse: CourseEntity? = null,
    val inProgressPercentage: Int = 35,
    val recommendedCourses: List<CourseEntity> = emptyList(),
    val todayChallenge: DailyChallengeEntity? = null,
    val recentAchievements: List<AchievementEntity> = emptyList(),
    val isChallengeSubmitted: Boolean = false,
    val challengeResultOutput: String? = null
)

class HomeViewModel(
    private val authRepository: AuthRepository,
    private val courseRepository: CourseRepository,
    private val progressRepository: ProgressRepository,
    private val practiceRepository: PracticeAndQuizRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                authRepository.getCurrentUserFlow(),
                courseRepository.getAllPublishedCoursesFlow(),
                practiceRepository.getTodayChallengeFlow(),
                progressRepository.getAllAchievementsFlow()
            ) { user, courses, challenge, achievements ->
                val primaryCourse = courses.firstOrNull()
                HomeUiState(
                    currentUser = user,
                    inProgressCourse = primaryCourse,
                    inProgressPercentage = 45,
                    recommendedCourses = courses.drop(1).take(4),
                    todayChallenge = challenge,
                    recentAchievements = achievements.take(3)
                )
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun submitDailyChallenge(code: String) {
        viewModelScope.launch {
            val user = _uiState.value.currentUser ?: return@launch
            val challenge = _uiState.value.todayChallenge ?: return@launch

            practiceRepository.completeDailyChallenge(
                challengeId = challenge.challengeId,
                uid = user.uid,
                xp = challenge.xpReward,
                coins = challenge.coinReward
            )

            _uiState.update {
                it.copy(
                    isChallengeSubmitted = true,
                    challengeResultOutput = "✓ Passed All Test Cases!\nOutput:\nracecar: True\nhello: False\n\n🎉 +${challenge.xpReward} XP & +${challenge.coinReward} Coins earned!"
                )
            }
        }
    }
}
