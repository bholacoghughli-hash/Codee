package com.example.ui.screens.playground

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.PlaygroundViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaygroundScreen(
    viewModel: PlaygroundViewModel,
    currentUid: String,
    onOpenAiTutor: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    val languages = listOf("Python", "JavaScript", "Kotlin", "SQL", "HTML/CSS")
    var showTemplatesDialog by remember { mutableStateOf(false) }
    var saveFileNameInput by remember { mutableStateOf("") }
    var showSaveDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Code Playground", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(uiState.selectedFileName, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    // Templates button
                    IconButton(onClick = { showTemplatesDialog = true }) {
                        Icon(Icons.Outlined.FolderSpecial, contentDescription = "Templates")
                    }

                    // Save file button
                    IconButton(onClick = {
                        saveFileNameInput = uiState.selectedFileName
                        showSaveDialog = true
                    }) {
                        Icon(Icons.Outlined.Save, contentDescription = "Save")
                    }

                    // AI Tutor assistant button
                    IconButton(onClick = onOpenAiTutor) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "AI Tutor", tint = IndigoAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Language selector & Run Action Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Language Chips
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    languages.forEach { lang ->
                        val isSelected = lang.equals(uiState.selectedLanguage, ignoreCase = true)
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectLanguage(lang) },
                            label = { Text(lang, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Run Code Button
                Button(
                    onClick = { viewModel.runCode() },
                    enabled = !uiState.isRunning,
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("playground_run_button")
                ) {
                    if (uiState.isRunning) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                    } else {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Run", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Code Editor Box with Line Numbers
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CodeBackground),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.2f)
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .border(1.dp, Color(0xFF30363D), RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                ) {
                    // Line numbers column
                    val lineCount = uiState.codeContent.lines().size.coerceAtLeast(1)
                    Column(
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        (1..lineCount).forEach { lineNum ->
                            Text(
                                text = "$lineNum",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                color = Color(0xFF484F58),
                                lineHeight = 20.sp
                            )
                        }
                    }

                    // Code Editor Text Field
                    BasicTextField(
                        value = uiState.codeContent,
                        onValueChange = { viewModel.updateCode(it) },
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = Color(0xFFE6EDF3),
                            lineHeight = 20.sp
                        ),
                        cursorBrush = SolidColor(CyanPrimary),
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .testTag("playground_code_editor")
                    )
                }
            }

            // Interactive Output Console Terminal
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1117)),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.8f)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .border(1.dp, Color(0xFF30363D), RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TERMINAL OUTPUT (${uiState.selectedLanguage.uppercase()})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B949E),
                            fontFamily = FontFamily.Monospace
                        )

                        if (uiState.isRunning) {
                            Text("RUNNING...", fontSize = 10.sp, color = AmberWarning, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = uiState.consoleOutput,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = when {
                            uiState.consoleOutput.contains("Error") -> Color(0xFFFF7B72)
                            uiState.consoleOutput.contains("Output") || uiState.consoleOutput.contains("Result") -> EmeraldSuccess
                            else -> Color(0xFFC9D1D9)
                        }
                    )
                }
            }
        }
    }

    // Starter Templates Dialog
    if (showTemplatesDialog) {
        AlertDialog(
            onDismissRequest = { showTemplatesDialog = false },
            title = { Text("Starter Code Templates", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    uiState.templates.forEach { tmpl ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.applyTemplate(tmpl)
                                    showTemplatesDialog = false
                                }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(tmpl.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(tmpl.language, fontSize = 11.sp, color = CyanPrimary, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(tmpl.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTemplatesDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // Save File Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save File to Profile") },
            text = {
                OutlinedTextField(
                    value = saveFileNameInput,
                    onValueChange = { saveFileNameInput = it },
                    label = { Text("File Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveFile(currentUid, saveFileNameInput.ifBlank { "my_code.py" })
                        showSaveDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
