package com.example.data.repository

import com.example.data.local.dao.BookmarkDao
import com.example.data.local.dao.CommunityDao
import com.example.data.local.dao.NoteDao
import com.example.data.local.dao.PlaygroundDao
import com.example.data.local.entity.BookmarkEntity
import com.example.data.local.entity.CommunityPostEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.PlaygroundFileEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class CommunityAndNoteRepository(
    private val communityDao: CommunityDao,
    private val noteDao: NoteDao,
    private val bookmarkDao: BookmarkDao,
    private val playgroundDao: PlaygroundDao
) {

    // Community
    fun getAllPostsFlow(): Flow<List<CommunityPostEntity>> = communityDao.getAllPostsFlow()
    fun getReportedPostsFlow(): Flow<List<CommunityPostEntity>> = communityDao.getReportedPostsFlow()

    suspend fun createPost(
        authorUid: String,
        authorName: String,
        authorRole: String,
        title: String,
        content: String,
        category: String,
        codeSnippet: String = "",
        language: String = ""
    ) {
        val post = CommunityPostEntity(
            postId = "post_" + UUID.randomUUID().toString().take(8),
            authorUid = authorUid,
            authorName = authorName,
            authorRole = authorRole,
            title = title,
            content = content,
            codeSnippet = codeSnippet,
            language = language,
            category = category,
            createdAt = System.currentTimeMillis()
        )
        communityDao.insertPost(post)
    }

    suspend fun likePost(postId: String) = communityDao.likePost(postId)
    suspend fun reportPost(postId: String) = communityDao.reportPost(postId)
    suspend fun deletePost(postId: String) = communityDao.deletePost(postId)

    // Notes
    fun getNotesForUserFlow(uid: String): Flow<List<NoteEntity>> = noteDao.getNotesForUserFlow(uid)
    fun getNoteForLessonFlow(uid: String, lessonId: String): Flow<NoteEntity?> =
        noteDao.getNoteForLessonFlow(uid, lessonId)

    suspend fun saveNote(uid: String, lessonId: String, lessonTitle: String, content: String) {
        val note = NoteEntity(
            noteId = "note_${uid}_${lessonId}",
            uid = uid,
            lessonId = lessonId,
            lessonTitle = lessonTitle,
            noteContent = content,
            updatedAt = System.currentTimeMillis()
        )
        noteDao.saveNote(note)
    }

    suspend fun deleteNote(noteId: String) = noteDao.deleteNote(noteId)

    // Bookmarks
    fun getBookmarksForUserFlow(uid: String): Flow<List<BookmarkEntity>> =
        bookmarkDao.getBookmarksForUserFlow(uid)

    fun isBookmarkedFlow(uid: String, lessonId: String): Flow<Boolean> =
        bookmarkDao.isBookmarkedFlow(uid, lessonId)

    suspend fun toggleBookmark(
        uid: String,
        lessonId: String,
        courseId: String,
        lessonTitle: String,
        courseTitle: String,
        isCurrentlyBookmarked: Boolean
    ) {
        if (isCurrentlyBookmarked) {
            bookmarkDao.deleteBookmark(uid, lessonId)
        } else {
            val bookmark = BookmarkEntity(
                bookmarkId = "bm_${uid}_${lessonId}",
                uid = uid,
                lessonId = lessonId,
                courseId = courseId,
                lessonTitle = lessonTitle,
                courseTitle = courseTitle,
                createdAt = System.currentTimeMillis()
            )
            bookmarkDao.insertBookmark(bookmark)
        }
    }

    // Playground Files
    fun getPlaygroundFilesFlow(uid: String): Flow<List<PlaygroundFileEntity>> =
        playgroundDao.getFilesForUserFlow(uid)

    suspend fun savePlaygroundFile(uid: String, fileName: String, language: String, code: String) {
        val file = PlaygroundFileEntity(
            fileId = "file_${uid}_${fileName.replace(" ", "_").lowercase()}",
            uid = uid,
            fileName = fileName,
            language = language,
            codeContent = code,
            updatedAt = System.currentTimeMillis()
        )
        playgroundDao.saveFile(file)
    }

    suspend fun deletePlaygroundFile(fileId: String) = playgroundDao.deleteFile(fileId)
}
