package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val uid: String,
    val fullName: String,
    val email: String,
    val phoneNumber: String = "",
    val profilePhoto: String = "",
    val role: String = "student", // "student" or "admin" only
    val preferredLanguage: String = "English", // English, Hindi, Hinglish
    val learningLevel: String = "Beginner", // Complete Beginner, Beginner, Intermediate, Advanced
    val learningGoal: String = "Web & App Development",
    val country: String = "India",
    val xp: Int = 120,
    val coins: Int = 50,
    val level: Int = 1,
    val streak: Int = 3,
    val lastLogin: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val accountStatus: String = "active", // "active" or "deactivated"
    val isEmailVerified: Boolean = true,
    val dailyGoalMinutes: Int = 20,
    val minutesLearnedToday: Int = 12
)
