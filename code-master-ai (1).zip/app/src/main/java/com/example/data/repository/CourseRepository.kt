package com.example.data.repository

import com.example.data.local.dao.CourseDao
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.ModuleEntity
import kotlinx.coroutines.flow.Flow

class CourseRepository(private val courseDao: CourseDao) {

    fun getAllPublishedCoursesFlow(): Flow<List<CourseEntity>> = courseDao.getAllPublishedCoursesFlow()

    fun getAllCoursesAdminFlow(): Flow<List<CourseEntity>> = courseDao.getAllCoursesAdminFlow()

    fun getCourseFlow(courseId: String): Flow<CourseEntity?> = courseDao.getCourseFlow(courseId)

    suspend fun getCourseById(courseId: String): CourseEntity? = courseDao.getCourseById(courseId)

    fun getCoursesByCategoryFlow(category: String): Flow<List<CourseEntity>> =
        courseDao.getCoursesByCategoryFlow(category)

    fun getModulesForCourseFlow(courseId: String): Flow<List<ModuleEntity>> =
        courseDao.getModulesForCourseFlow(courseId)

    fun getLessonsForCourseFlow(courseId: String): Flow<List<LessonEntity>> =
        courseDao.getLessonsForCourseFlow(courseId)

    fun getLessonsForModuleFlow(moduleId: String): Flow<List<LessonEntity>> =
        courseDao.getLessonsForModuleFlow(moduleId)

    fun getLessonFlow(lessonId: String): Flow<LessonEntity?> = courseDao.getLessonFlow(lessonId)

    suspend fun getLessonById(lessonId: String): LessonEntity? = courseDao.getLessonById(lessonId)

    // Admin Operations
    suspend fun saveCourse(course: CourseEntity) {
        courseDao.insertCourse(course)
    }

    suspend fun saveLesson(lesson: LessonEntity) {
        courseDao.insertLesson(lesson)
    }

    suspend fun deleteCourse(courseId: String) {
        courseDao.deleteCourseById(courseId)
    }
}
