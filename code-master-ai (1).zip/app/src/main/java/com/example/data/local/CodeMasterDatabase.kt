package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.*
import com.example.data.local.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        CourseEntity::class,
        ModuleEntity::class,
        LessonEntity::class,
        UserProgressEntity::class,
        QuizEntity::class,
        ProjectEntity::class,
        CertificateEntity::class,
        AchievementEntity::class,
        DailyChallengeEntity::class,
        BookmarkEntity::class,
        NoteEntity::class,
        CommunityPostEntity::class,
        PlaygroundFileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CodeMasterDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun courseDao(): CourseDao
    abstract fun progressDao(): ProgressDao
    abstract fun quizDao(): QuizDao
    abstract fun projectDao(): ProjectDao
    abstract fun certificateDao(): CertificateDao
    abstract fun achievementDao(): AchievementDao
    abstract fun dailyChallengeDao(): DailyChallengeDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun noteDao(): NoteDao
    abstract fun communityDao(): CommunityDao
    abstract fun playgroundDao(): PlaygroundDao

    companion object {
        @Volatile
        private var INSTANCE: CodeMasterDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): CodeMasterDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CodeMasterDatabase::class.java,
                    "code_master_ai.db"
                )
                .addCallback(DatabaseCallback(scope))
                .fallbackToDestructiveMigration(true)
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDatabase(database)
                    }
                }
            }
        }

        suspend fun populateDatabase(db: CodeMasterDatabase) {
            val userDao = db.userDao()
            val courseDao = db.courseDao()
            val quizDao = db.quizDao()
            val projectDao = db.projectDao()
            val achievementDao = db.achievementDao()
            val dailyChallengeDao = db.dailyChallengeDao()
            val communityDao = db.communityDao()
            val certificateDao = db.certificateDao()

            // Preload Users
            userDao.insertUser(SeedData.adminUser)
            userDao.insertUser(SeedData.demoStudentUser)

            // Preload Courses, Modules, Lessons
            courseDao.insertCourses(SeedData.initialCourses)
            courseDao.insertModules(SeedData.initialModules)
            courseDao.insertLessons(SeedData.initialLessons)

            // Preload Quizzes & Projects
            quizDao.insertQuizzes(SeedData.initialQuizzes)
            projectDao.insertProjects(SeedData.initialProjects)

            // Preload Achievements & Daily Challenge
            achievementDao.insertAchievements(SeedData.initialAchievements)
            dailyChallengeDao.insertChallenges(listOf(SeedData.initialDailyChallenge))

            // Preload Community & Sample Certificate
            communityDao.insertPosts(SeedData.initialCommunityPosts)
            for (cert in SeedData.sampleCertificates) {
                certificateDao.insertCertificate(cert)
            }
        }
    }
}
