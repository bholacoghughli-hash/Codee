package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "courses")
data class CourseEntity(
    @PrimaryKey val courseId: String,
    val title: String,
    val description: String,
    val category: String, // Web Development, Programming, Mobile Development, Database, Computer Science, Advanced AI
    val iconName: String, // python, js, html, kotlin, sql, ai, etc.
    val level: String, // Beginner, Intermediate, Advanced
    val estimatedHours: Int,
    val totalLessons: Int,
    val totalQuizzes: Int,
    val totalProjects: Int,
    val badgeName: String,
    val isPublished: Boolean = true,
    val enrolledCount: Int = 1250,
    val rating: Float = 4.9f
)

@Entity(tableName = "modules")
data class ModuleEntity(
    @PrimaryKey val moduleId: String,
    val courseId: String,
    val moduleNumber: Int,
    val title: String,
    val description: String
)

@Entity(tableName = "lessons")
data class LessonEntity(
    @PrimaryKey val lessonId: String,
    val courseId: String,
    val moduleId: String,
    val lessonNumber: Int,
    val title: String,
    val objective: String,
    val simpleExplanation: String,
    val simplifiedExplanation: String, // For Easy Mode ("Explain Simply")
    val realLifeAnalogy: String,
    val visualDiagram: String,
    val codeExample: String,
    val codeLanguage: String, // python, javascript, kotlin, html, sql, cpp
    val expectedOutput: String,
    val tryItYourselfPrompt: String,
    val tryItYourselfStarterCode: String,
    val tryItYourselfSolution: String,
    val commonMistakes: String,
    val quickSummary: String,
    val miniQuizQuestion: String,
    val miniQuizOptions: String, // comma or pipe separated
    val miniQuizAnswerIndex: Int,
    val miniQuizExplanation: String,
    val xpReward: Int = 20,
    val coinReward: Int = 5
)
