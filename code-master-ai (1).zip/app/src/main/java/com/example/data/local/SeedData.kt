package com.example.data.local

import com.example.data.local.entity.*

object SeedData {

    val adminUser = UserEntity(
        uid = "admin_master_01",
        fullName = "Bhaskar (Super Admin)",
        email = "admin@codemaster.ai",
        phoneNumber = "+91 9876543210",
        role = "admin",
        preferredLanguage = "English",
        learningLevel = "Advanced",
        learningGoal = "Platform Architecture",
        country = "India",
        xp = 9999,
        coins = 2500,
        level = 50,
        streak = 100,
        accountStatus = "active"
    )

    val demoStudentUser = UserEntity(
        uid = "student_demo_01",
        fullName = "Aarav Sharma",
        email = "student@codemaster.ai",
        phoneNumber = "+91 9123456780",
        role = "student",
        preferredLanguage = "English",
        learningLevel = "Beginner",
        learningGoal = "Become a Full-Stack & Android Developer",
        country = "India",
        xp = 480,
        coins = 120,
        level = 3,
        streak = 5,
        accountStatus = "active",
        dailyGoalMinutes = 20,
        minutesLearnedToday = 15
    )

    val initialCourses = listOf(
        CourseEntity(
            courseId = "course_python",
            title = "Python for Absolute Beginners",
            description = "Master Python from scratch with interactive lessons, instant code execution, real-world analogies, and hands-on projects.",
            category = "Programming",
            iconName = "python",
            level = "Beginner",
            estimatedHours = 12,
            totalLessons = 9,
            totalQuizzes = 3,
            totalProjects = 2,
            badgeName = "Python Pioneer",
            isPublished = true,
            enrolledCount = 3840,
            rating = 4.95f
        ),
        CourseEntity(
            courseId = "course_webdev",
            title = "Modern Web Dev: HTML, CSS & JavaScript",
            description = "Build responsive, beautiful websites and interactive web apps with modern HTML5, CSS3 Flexbox, and JavaScript ES6+.",
            category = "Web Development",
            iconName = "javascript",
            level = "Beginner",
            estimatedHours = 18,
            totalLessons = 8,
            totalQuizzes = 3,
            totalProjects = 2,
            badgeName = "Web Architect",
            isPublished = true,
            enrolledCount = 5120,
            rating = 4.92f
        ),
        CourseEntity(
            courseId = "course_kotlin",
            title = "Kotlin & Android Jetpack Compose",
            description = "Develop production-ready native Android apps with Kotlin, declarative Jetpack Compose UI, Coroutines, and MVVM architecture.",
            category = "Mobile Development",
            iconName = "kotlin",
            level = "Intermediate",
            estimatedHours = 15,
            totalLessons = 6,
            totalQuizzes = 2,
            totalProjects = 2,
            badgeName = "Android Master",
            isPublished = true,
            enrolledCount = 2780,
            rating = 4.98f
        ),
        CourseEntity(
            courseId = "course_sql",
            title = "SQL & Relational Database Mastery",
            description = "Design schemas, write performant SQL queries, master JOINs, aggregates, indexes, and database normalization.",
            category = "Database",
            iconName = "sql",
            level = "Beginner",
            estimatedHours = 10,
            totalLessons = 6,
            totalQuizzes = 2,
            totalProjects = 1,
            badgeName = "Data Champion",
            isPublished = true,
            enrolledCount = 1940,
            rating = 4.88f
        ),
        CourseEntity(
            courseId = "course_genai",
            title = "Generative AI & Prompt Engineering",
            description = "Harness the power of Large Language Models, learn few-shot prompt crafting, tool calling, and AI application engineering.",
            category = "Advanced AI",
            iconName = "ai",
            level = "Beginner",
            estimatedHours = 8,
            totalLessons = 5,
            totalQuizzes = 2,
            totalProjects = 1,
            badgeName = "AI Alchemist",
            isPublished = true,
            enrolledCount = 4210,
            rating = 4.97f
        ),
        CourseEntity(
            courseId = "course_dsa",
            title = "Data Structures & Algorithms in Practice",
            description = "Crack coding interviews by mastering Big-O complexity, Arrays, HashMaps, Stacks, Queues, and dynamic problem solving.",
            category = "Computer Science",
            iconName = "dsa",
            level = "Intermediate",
            estimatedHours = 20,
            totalLessons = 6,
            totalQuizzes = 2,
            totalProjects = 2,
            badgeName = "Algorithm Ace",
            isPublished = true,
            enrolledCount = 3100,
            rating = 4.94f
        )
    )

    val initialModules = listOf(
        // Python Modules
        ModuleEntity(
            moduleId = "mod_py_1",
            courseId = "course_python",
            moduleNumber = 1,
            title = "Python Fundamentals & Syntax",
            description = "Start your coding journey: install Python, understand syntax, print output, and master variables."
        ),
        ModuleEntity(
            moduleId = "mod_py_2",
            courseId = "course_python",
            moduleNumber = 2,
            title = "Logic, Conditions & Loops",
            description = "Control program flow with boolean logic, if-else statements, and automated repetition with loops."
        ),
        ModuleEntity(
            moduleId = "mod_py_3",
            courseId = "course_python",
            moduleNumber = 3,
            title = "Functions & Data Collections",
            description = "Write clean reusable modular functions, lists, and key-value dictionaries."
        ),

        // Web Dev Modules
        ModuleEntity(
            moduleId = "mod_web_1",
            courseId = "course_webdev",
            moduleNumber = 1,
            title = "HTML5 Essentials",
            description = "Structure web documents with semantic tags, headings, links, images, and user input forms."
        ),
        ModuleEntity(
            moduleId = "mod_web_2",
            courseId = "course_webdev",
            moduleNumber = 2,
            title = "CSS3 Styling & Modern Flexbox",
            description = "Style your pages with colors, typography, box model spacing, and responsive layout grids."
        ),
        ModuleEntity(
            moduleId = "mod_web_3",
            courseId = "course_webdev",
            moduleNumber = 3,
            title = "JavaScript Interactivity & DOM",
            description = "Bring web pages to life with event listeners, dynamic DOM manipulation, and modern ES6 functions."
        ),

        // Kotlin Modules
        ModuleEntity(
            moduleId = "mod_kt_1",
            courseId = "course_kotlin",
            moduleNumber = 1,
            title = "Kotlin Language Core",
            description = "Learn Kotlin val/var, null safety, smart casts, lambda functions, and data classes."
        ),
        ModuleEntity(
            moduleId = "mod_kt_2",
            courseId = "course_kotlin",
            moduleNumber = 2,
            title = "Jetpack Compose UI Framework",
            description = "Declarative UI architecture, Column/Row layouts, state hoisting, and Material 3 components."
        ),

        // SQL Modules
        ModuleEntity(
            moduleId = "mod_sql_1",
            courseId = "course_sql",
            moduleNumber = 1,
            title = "SQL Query Fundamentals",
            description = "Query relational tables using SELECT, WHERE, ORDER BY, and LIMIT clauses."
        ),

        // AI Modules
        ModuleEntity(
            moduleId = "mod_ai_1",
            courseId = "course_genai",
            moduleNumber = 1,
            title = "Prompt Engineering Principles",
            description = "Master prompt structure: Persona, Task, Context, Constraints, and Output Format."
        ),

        // DSA Modules
        ModuleEntity(
            moduleId = "mod_dsa_1",
            courseId = "course_dsa",
            moduleNumber = 1,
            title = "Complexity Analysis & Arrays",
            description = "Understand Big-O time & space complexity, array memory layouts, and two-pointer traversal."
        )
    )

    val initialLessons = listOf(
        // Python Lesson 1
        LessonEntity(
            lessonId = "les_py_1",
            courseId = "course_python",
            moduleId = "mod_py_1",
            lessonNumber = 1,
            title = "What is Python & Your First Program",
            objective = "Understand what Python is, why it's the world's most popular language, and execute your first line of code.",
            simpleExplanation = "Python is a high-level, human-readable programming language. Unlike complicated low-level code, Python reads almost like plain English. The `print()` function tells your computer to display text onto the screen.",
            simplifiedExplanation = "Think of Python like giving instructions to a smart friend. When you write `print('Hello!')`, you are telling the computer: 'Hey, shout this message onto the screen!' That is all there is to your first program!",
            realLifeAnalogy = "Imagine speaking into a microphone. Whatever words you put inside the parentheses `(\"...\")` are broadcast out through the speaker (your screen).",
            visualDiagram = "[ Your Code: print('Hi!') ]  -->  [ Python Interpreter ]  -->  [ Screen Output: Hi! ]",
            codeExample = "print(\"Welcome to Code Master AI!\")\nprint(\"Created by Bhaskar\")\nprint(\"Coding is fun and simple!\")",
            codeLanguage = "python",
            expectedOutput = "Welcome to Code Master AI!\nCreated by Bhaskar\nCoding is fun and simple!",
            tryItYourselfPrompt = "Change the text inside the print function to output your own name and favorite hobby.",
            tryItYourselfStarterCode = "name = \"Developer\"\nprint(\"Hello! My name is\", name)",
            tryItYourselfSolution = "name = \"Bhaskar\"\nprint(\"Hello! My name is\", name)\nprint(\"I love building software!\")",
            commonMistakes = "1. Forgetting matching quotation marks around text: print(\"Hello) -> SyntaxError.\n2. Capitalizing Print() instead of lowercase print().\n3. Missing parentheses.",
            quickSummary = "• Python is beginner-friendly and clean.\n• Use print(\"...\") to display messages.\n• Text inside quotes is called a String.",
            miniQuizQuestion = "Which of the following correctly outputs 'Hello, World!' in Python?",
            miniQuizOptions = "print(\"Hello, World!\")|echo \"Hello, World!\"|System.out.print(\"Hello\");|console.log(\"Hello\")",
            miniQuizAnswerIndex = 0,
            miniQuizExplanation = "In Python, the built-in function `print(...)` is used to output text to the console.",
            xpReward = 25,
            coinReward = 5
        ),

        // Python Lesson 2
        LessonEntity(
            lessonId = "les_py_2",
            courseId = "course_python",
            moduleId = "mod_py_1",
            lessonNumber = 2,
            title = "Variables & Data Types",
            objective = "Learn how to store numbers, text, and true/false states in memory using named variables.",
            simpleExplanation = "A variable is like a labeled storage box in computer memory. You assign data to it using the equals sign (`=`). Common data types include `str` (text), `int` (whole numbers), `float` (decimals), and `bool` (True/False).",
            simplifiedExplanation = "Imagine labeled containers in your kitchen: one for 'Sugar', one for 'Coffee'. In code: `sugar = 5` means you put the number 5 inside the container named 'sugar'.",
            realLifeAnalogy = "Your phone's contact list: 'Mom' (variable name) points to '+91 9876543210' (value stored).",
            visualDiagram = "[ Variable Name: score ]  =====>  [ Memory Box: 100 (int) ]",
            codeExample = "student_name = \"Alex\"\nage = 16\ngpa = 3.85\nis_enrolled = True\n\nprint(\"Student:\", student_name)\nprint(\"Age:\", age)\nprint(\"GPA:\", gpa)\nprint(\"Enrolled:\", is_enrolled)",
            codeLanguage = "python",
            expectedOutput = "Student: Alex\nAge: 16\nGPA: 3.85\nEnrolled: True",
            tryItYourselfPrompt = "Create two variables: `x = 25` and `y = 15`. Add them together and print the result.",
            tryItYourselfStarterCode = "x = 25\ny = 15\n# Calculate sum here\ntotal = x + y\nprint(\"Total:\", total)",
            tryItYourselfSolution = "x = 25\ny = 15\ntotal = x + y\nprint(\"Total:\", total)",
            commonMistakes = "1. Using numbers or special symbols at the beginning of variable names (e.g. 2nd_name is invalid).\n2. Confusing single `=` (assignment) with `==` (comparison).",
            quickSummary = "• Variables hold data in memory.\n• Integer (1, 2), Float (3.14), String (\"text\"), Boolean (True, False).\n• Python automatically identifies the type.",
            miniQuizQuestion = "What type of data is represented by `is_active = True`?",
            miniQuizOptions = "String (str)|Integer (int)|Boolean (bool)|Float (float)",
            miniQuizAnswerIndex = 2,
            miniQuizExplanation = "`True` and `False` values without quotes are Boolean data types in Python.",
            xpReward = 25,
            coinReward = 5
        ),

        // Python Lesson 3
        LessonEntity(
            lessonId = "les_py_3",
            courseId = "course_python",
            moduleId = "mod_py_2",
            lessonNumber = 3,
            title = "Conditional Logic: if, elif & else",
            objective = "Enable your programs to make intelligent decisions based on conditions.",
            simpleExplanation = "Conditionals allow your code to take different paths. If a condition evaluates to `True`, the indented block under `if` runs. If not, Python checks subsequent `elif` blocks or defaults to `else`.",
            simplifiedExplanation = "If it rains, take an umbrella. Else if it is cloudy, wear a jacket. Else, wear sunglasses. That is exactly how `if`, `elif`, and `else` work in code!",
            realLifeAnalogy = "A traffic light: If green -> Go. If yellow -> Slow down. If red -> Stop.",
            visualDiagram = "[ Check Condition ] --> True  --> [ Run If Block ]\n                     --> False --> [ Check Next / Else ]",
            codeExample = "score = 85\n\nif score >= 90:\n    print(\"Grade: A (Outstanding!)\")\nelif score >= 75:\n    print(\"Grade: B (Good Job!)\")\nelif score >= 50:\n    print(\"Grade: C (Pass)\")\nelse:\n    print(\"Needs Improvement\")",
            codeLanguage = "python",
            expectedOutput = "Grade: B (Good Job!)",
            tryItYourselfPrompt = "Write an if-else check for a user's age: if 18 or older, print 'Eligible to vote', otherwise print 'Too young'.",
            tryItYourselfStarterCode = "age = 20\n# Write condition here",
            tryItYourselfSolution = "age = 20\nif age >= 18:\n    print(\"Eligible to vote\")\nelse:\n    print(\"Too young\")",
            commonMistakes = "1. Forgetting the colon `:` at the end of the `if` line.\n2. Inconsistent indentation (Python requires 4 spaces for block bodies).",
            quickSummary = "• `if` tests a condition.\n• `elif` allows multiple sequential checks.\n• `else` catches all remaining cases.\n• Indentation defines the code block.",
            miniQuizQuestion = "What symbol must be placed at the end of an `if` or `else` line in Python?",
            miniQuizOptions = "Semicolon (;)|Colon (:)|Curly brace ({)|Period (.)",
            miniQuizAnswerIndex = 1,
            miniQuizExplanation = "Python requires a colon `:` at the end of control statements like `if`, `for`, `def`.",
            xpReward = 30,
            coinReward = 10
        ),

        // Python Lesson 4
        LessonEntity(
            lessonId = "les_py_4",
            courseId = "course_python",
            moduleId = "mod_py_2",
            lessonNumber = 4,
            title = "Loops in Python: for & while",
            objective = "Automate repetitive tasks effortlessly using loops and ranges.",
            simpleExplanation = "A `for` loop iterates through a sequence of items or a range of numbers. A `while` loop continues executing as long as its condition remains `True`.",
            simplifiedExplanation = "Instead of writing `print('Repeat')` 100 times, a loop tells the computer: 'Do this 100 times for me in one millisecond!'",
            realLifeAnalogy = "Doing 10 jumping jacks: you count 1, 2, 3... until you reach 10.",
            visualDiagram = "[ Start Loop ] --> [ Execute Task ] --> [ Increment Count ] --> [ Loop Finished? ]",
            codeExample = "print(\"--- For Loop with range ---\")\nfor i in range(1, 6):\n    print(f\"Step {i}: Keep Coding!\")\n\nprint(\"\\n--- Iterating over a list ---\")\nlanguages = [\"Python\", \"JavaScript\", \"Kotlin\"]\nfor lang in languages:\n    print(f\"I am learning {lang}\")",
            codeLanguage = "python",
            expectedOutput = "--- For Loop with range ---\nStep 1: Keep Coding!\nStep 2: Keep Coding!\nStep 3: Keep Coding!\nStep 4: Keep Coding!\nStep 5: Keep Coding!\n\n--- Iterating over a list ---\nI am learning Python\nI am learning JavaScript\nI am learning Kotlin",
            tryItYourselfPrompt = "Write a loop that calculates and prints the sum of numbers from 1 to 5.",
            tryItYourselfStarterCode = "total = 0\nfor num in range(1, 6):\n    total += num\nprint(\"Sum:\", total)",
            tryItYourselfSolution = "total = 0\nfor num in range(1, 6):\n    total += num\nprint(\"Sum:\", total)",
            commonMistakes = "1. Infinite while loop caused by forgetting to increment the counter variable.\n2. Off-by-one errors: `range(1, 5)` stops at 4, not 5.",
            quickSummary = "• `for item in sequence:` repeats for each item.\n• `range(start, stop)` generates numbers up to stop-1.\n• Loops save thousands of lines of manual code.",
            miniQuizQuestion = "How many times will `for x in range(3):` run?",
            miniQuizOptions = "2 times|3 times (0, 1, 2)|4 times|Infinite",
            miniQuizAnswerIndex = 1,
            miniQuizExplanation = "`range(3)` produces the sequence `0, 1, 2`, running exactly 3 times.",
            xpReward = 30,
            coinReward = 10
        ),

        // Python Lesson 5: Functions
        LessonEntity(
            lessonId = "les_py_5",
            courseId = "course_python",
            moduleId = "mod_py_3",
            lessonNumber = 5,
            title = "Reusable Functions in Python",
            objective = "Organize code into clean, testable, and reusable blocks using `def` and `return`.",
            simpleExplanation = "Functions are blocks of code that perform a specific action and only run when called. You can pass inputs (arguments) and receive an output (`return`).",
            simplifiedExplanation = "Think of a blender. You put fruits inside (arguments), press start (run function), and it gives you a smoothie (return value).",
            realLifeAnalogy = "A recipe card: Whenever you want to bake a cake, you follow the recipe without writing it from scratch each time.",
            visualDiagram = "[ Inputs (a, b) ]  =====>  [ def add(a, b): return a + b ]  =====>  [ Output Result ]",
            codeExample = "def calculate_discount(price, discount_percent):\n    discount_amount = price * (discount_percent / 100)\n    final_price = price - discount_amount\n    return final_price\n\nlaptop_price = 1000\nsale_price = calculate_discount(laptop_price, 20)\nprint(f\"Original: \${laptop_price}, Sale: \${sale_price}\")",
            codeLanguage = "python",
            expectedOutput = "Original: \$1000, Sale: \$800.0",
            tryItYourselfPrompt = "Create a function `greet(name)` that returns 'Welcome, {name} to Code Master AI!'.",
            tryItYourselfStarterCode = "def greet(name):\n    # Return greeting\n    pass\n\nprint(greet(\"Bhaskar\"))",
            tryItYourselfSolution = "def greet(name):\n    return f\"Welcome, {name} to Code Master AI!\"\n\nprint(greet(\"Bhaskar\"))",
            commonMistakes = "1. Printing inside the function when you intended to `return` the value.\n2. Calling a function before it has been defined in the file.",
            quickSummary = "• `def function_name(params):` defines a function.\n• `return` passes data back to caller.\n• Functions make code modular and DRY (Don't Repeat Yourself).",
            miniQuizQuestion = "Which keyword is used in Python to define a new function?",
            miniQuizOptions = "func|function|def|define",
            miniQuizAnswerIndex = 2,
            miniQuizExplanation = "Python uses `def` (short for define) to declare functions.",
            xpReward = 35,
            coinReward = 10
        ),

        // Web Dev Lesson 1
        LessonEntity(
            lessonId = "les_web_1",
            courseId = "course_webdev",
            moduleId = "mod_web_1",
            lessonNumber = 1,
            title = "HTML5 Skeleton & Semantic Tags",
            objective = "Learn how web pages are structured using tags, headings, paragraphs, and containers.",
            simpleExplanation = "HTML (HyperText Markup Language) is the standard markup language for documents designed to be displayed in a web browser. Tags wrapped in `<...>` give structure and meaning to content.",
            simplifiedExplanation = "HTML is like the skeleton of a human body. It defines where the head, torso, arms, and legs are, before CSS adds clothes and styling!",
            realLifeAnalogy = "A newspaper layout: Main headline `<h1>`, subheadings `<h2>`, body paragraphs `<p>`, and sections `<article>`.",
            visualDiagram = "<html> -> <head> (Metadata) + <body> (Visible UI: <h1>, <p>, <button>)",
            codeExample = "<!DOCTYPE html>\n<html>\n  <head>\n    <title>My First Website</title>\n  </head>\n  <body>\n    <h1>Welcome to Code Master AI</h1>\n    <p>Learn coding step by step with interactive lessons.</p>\n    <button onclick=\"alert('Hello Developer!')\">Click Me</button>\n  </body>\n</html>",
            codeLanguage = "html",
            expectedOutput = "Welcome to Code Master AI\nLearn coding step by step with interactive lessons.\n[Click Me Button]",
            tryItYourselfPrompt = "Add a secondary heading `<h2>` with your favorite programming language.",
            tryItYourselfStarterCode = "<h1>My Profile</h1>\n<!-- Add h2 and p tags here -->",
            tryItYourselfSolution = "<h1>My Profile</h1>\n<h2>Favorite Language: Python & Kotlin</h2>\n<p>Built with Code Master AI</p>",
            commonMistakes = "1. Forgetting closing tags like `</h1>` or `</p>`.\n2. Nesting tags incorrectly.",
            quickSummary = "• HTML structures the content of the web.\n• `<h1>` to `<h6>` are headings.\n• `<p>` is for paragraphs, `<button>` for actions.",
            miniQuizQuestion = "Which HTML tag is used for the highest-level main heading?",
            miniQuizOptions = "<head>|<h6>|<h1>|<header>",
            miniQuizAnswerIndex = 2,
            miniQuizExplanation = "`<h1>` represents the primary top-level heading on a web page.",
            xpReward = 25,
            coinReward = 5
        ),

        // Web Dev Lesson 2: JavaScript
        LessonEntity(
            lessonId = "les_web_2",
            courseId = "course_webdev",
            moduleId = "mod_web_3",
            lessonNumber = 2,
            title = "JavaScript ES6: Variables & Functions",
            objective = "Write modern JavaScript using `let`, `const`, arrow functions, and console debugging.",
            simpleExplanation = "JavaScript is the programming language of the web. It allows web pages to react to user actions, perform calculations, and update content in real-time.",
            simplifiedExplanation = "If HTML is the skeleton and CSS is the clothes, JavaScript is the brain and muscles that allow the person to walk, talk, and think!",
            realLifeAnalogy = "The light switch in your room: When you press it, JavaScript turns the light on.",
            visualDiagram = "[ User Clicks Button ]  -->  [ JS Event Listener ]  -->  [ DOM Updates Instantly ]",
            codeExample = "// Declare variables\nconst appName = \"Code Master AI\";\nlet activeUsers = 1500;\n\n// Modern Arrow Function\nconst calculateBonus = (xp, multiplier) => {\n  return xp * multiplier;\n};\n\nconsole.log(`Welcome to \${appName}`);\nconsole.log(`Active Learners: \${activeUsers}`);\nconsole.log(`Earned XP: \${calculateBonus(100, 1.5)}`);",
            codeLanguage = "javascript",
            expectedOutput = "Welcome to Code Master AI\nActive Learners: 1500\nEarned XP: 150",
            tryItYourselfPrompt = "Create a function `square(num)` that returns the square of a number.",
            tryItYourselfStarterCode = "const square = (n) => {\n  // Write formula\n};\nconsole.log(square(6));",
            tryItYourselfSolution = "const square = (n) => n * n;\nconsole.log(square(6));",
            commonMistakes = "1. Reassigning a `const` variable (throws TypeError).\n2. Forgetting backticks when using template literals \${'$'}{variable}.",
            quickSummary = "• Use `const` by default, `let` when values change.\n• Arrow functions `() => {}` provide clean syntax.\n• Template strings use `\${'$'}{}` inside backticks.",
            miniQuizQuestion = "Which keyword declares a variable that cannot be reassigned?",
            miniQuizOptions = "var|let|const|static",
            miniQuizAnswerIndex = 2,
            miniQuizExplanation = "`const` creates a block-scoped immutable variable reference.",
            xpReward = 30,
            coinReward = 10
        ),

        // Kotlin Lesson 1
        LessonEntity(
            lessonId = "les_kt_1",
            courseId = "course_kotlin",
            moduleId = "mod_kt_1",
            lessonNumber = 1,
            title = "Kotlin Fundamentals & Null Safety",
            objective = "Learn why Kotlin is the modern choice for Android, with val/var and built-in null safety.",
            simpleExplanation = "Kotlin is a modern, expressive, type-safe programming language endorsed by Google for Android development. Its standout feature is compile-time null safety, eliminating the dreaded `NullPointerException`.",
            simplifiedExplanation = "Kotlin won't let your app crash from missing data. If a variable might be empty, Kotlin forces you to safely check it before using it!",
            realLifeAnalogy = "A safety harness when rock climbing: Kotlin catches potential falls before they happen.",
            visualDiagram = "val name: String = \"Bhaskar\"  (Non-null by default)\nval bio: String? = null       (Nullable with ? mark)",
            codeExample = "fun main() {\n    val appTitle: String = \"Code Master AI\"\n    var currentStreak: Int = 7\n    \n    // Nullable string safely checked\n    val userBio: String? = \"Android Developer\"\n    \n    println(\"App: \$appTitle\")\n    println(\"Streak: \$currentStreak days\")\n    println(\"Bio Length: \${userBio?.length ?: 0}\")\n}",
            codeLanguage = "kotlin",
            expectedOutput = "App: Code Master AI\nStreak: 7 days\nBio Length: 17",
            tryItYourselfPrompt = "Create a data class `Student(val name: String, val xp: Int)` and print an instance.",
            tryItYourselfStarterCode = "data class Student(val name: String, val xp: Int)\n\nfun main() {\n    val s = Student(\"Bhaskar\", 500)\n    println(s)\n}",
            tryItYourselfSolution = "data class Student(val name: String, val xp: Int)\n\nfun main() {\n    val s = Student(\"Bhaskar\", 500)\n    println(\"Student: \${s.name}, XP: \${s.xp}\")\n}",
            commonMistakes = "1. Trying to reassign a `val` (val is read-only like const; use var for mutable).\n2. Calling methods directly on a nullable type without `?.` or safe check.",
            quickSummary = "• `val` is immutable; `var` is mutable.\n• Type system distinguishes nullable (`T?`) and non-null (`T`).\n• Elvis operator `?:` provides default fallback values.",

            miniQuizQuestion = "Which operator in Kotlin provides a fallback value when an expression is null?",
            miniQuizOptions = "Nullish (??)|Elvis operator (?:)|Safe call (?.)|Assertion (!!)",
            miniQuizAnswerIndex = 1,
            miniQuizExplanation = "The Elvis operator `?:` returns the right-hand value if the left-hand is null.",
            xpReward = 30,
            coinReward = 10
        ),

        // SQL Lesson 1
        LessonEntity(
            lessonId = "les_sql_1",
            courseId = "course_sql",
            moduleId = "mod_sql_1",
            lessonNumber = 1,
            title = "Relational Databases & SQL SELECT",
            objective = "Query databases to extract structured records with filtering and sorting.",
            simpleExplanation = "SQL (Structured Query Language) is the language used to manage and query relational databases like MySQL, PostgreSQL, and SQLite.",
            simplifiedExplanation = "SQL is like asking a librarian: 'Please give me all books by author Bhaskar, sorted by newest first!'",
            realLifeAnalogy = "Searching for products on Amazon with filters (Category = Electronics, Price < 500).",
            visualDiagram = "[ Table: students ]  -->  [ WHERE xp > 100 ORDER BY xp DESC ]  -->  [ Filtered Results ]",
            codeExample = "-- Select all active students with high XP\nSELECT full_name, email, xp, level\nFROM students\nWHERE account_status = 'active' AND xp >= 100\nORDER BY xp DESC\nLIMIT 5;",
            codeLanguage = "sql",
            expectedOutput = "+---------------+----------------------+-----+-------+\n| full_name     | email                | xp  | level |\n+---------------+----------------------+-----+-------+\n| Bhaskar       | admin@codemaster.ai  | 9999| 50    |\n| Aarav Sharma  | student@codemaster.ai| 480 | 3     |\n+---------------+----------------------+-----+-------+",
            tryItYourselfPrompt = "Write a query to select all courses where `category` is 'Programming'.",
            tryItYourselfStarterCode = "SELECT * FROM courses\n-- Add WHERE condition",
            tryItYourselfSolution = "SELECT * FROM courses\nWHERE category = 'Programming'\nORDER BY rating DESC;",
            commonMistakes = "1. Missing single quotes around string literals in WHERE clause.\n2. Confusing `AND` / `OR` operator precedence.",
            quickSummary = "• `SELECT` chooses columns.\n• `FROM` specifies the table.\n• `WHERE` filters rows.\n• `ORDER BY` sorts results.",
            miniQuizQuestion = "Which SQL clause is used to filter rows that meet specified conditions?",
            miniQuizOptions = "ORDER BY|FILTER|WHERE|GROUP BY",
            miniQuizAnswerIndex = 2,
            miniQuizExplanation = "The `WHERE` clause filters records based on boolean conditions.",
            xpReward = 25,
            coinReward = 5
        )
    )

    val initialQuizzes = listOf(
        QuizEntity(
            quizId = "quiz_py_1",
            courseId = "course_python",
            moduleId = "mod_py_1",
            title = "Python Fundamentals Assessment",
            timeLimitMinutes = 5,
            passingScorePercent = 70,
            xpReward = 60,
            coinReward = 20,
            questionsData = """[
                {"q": "What is the output of print(2 ** 3) in Python?", "options": ["6", "8", "9", "5"], "ans": 1, "exp": "The ** operator in Python is exponentiation: 2^3 = 8."},
                {"q": "How do you start a single-line comment in Python?", "options": ["//", "/*", "#", "--"], "ans": 2, "exp": "Python uses the hash symbol # for single-line comments."},
                {"q": "Which data type is result of 10 / 2 in Python 3?", "options": ["int (5)", "float (5.0)", "str ('5')", "double (5.00)"], "ans": 1, "exp": "The standard division / operator always produces a float in Python 3."},
                {"q": "What function is used to get keyboard input from the user?", "options": ["read()", "input()", "scan()", "get()"], "ans": 1, "exp": "input() pauses the program and returns the user input as a string."}
            ]"""
        ),
        QuizEntity(
            quizId = "quiz_web_1",
            courseId = "course_webdev",
            moduleId = "mod_web_1",
            title = "HTML5 & Web Architecture Quiz",
            timeLimitMinutes = 5,
            passingScorePercent = 70,
            xpReward = 60,
            coinReward = 20,
            questionsData = """[
                {"q": "What does HTML stand for?", "options": ["HyperText Markup Language", "Hyperlinks and Text Management", "Home Tool Markup Language", "High-Tech Modern Language"], "ans": 0, "exp": "HTML stands for HyperText Markup Language."},
                {"q": "Which HTML tag is used to create a clickable hyperlink?", "options": ["<link>", "<a>", "<href>", "<nav>"], "ans": 1, "exp": "The <a> (anchor) tag creates hyperlinks via its href attribute."},
                {"q": "Where in an HTML document should metadata like title and charset be placed?", "options": ["<body>", "<head>", "<footer>", "<header>"], "ans": 1, "exp": "Metadata belongs in the <head> container."}
            ]"""
        )
    )

    val initialProjects = listOf(
        ProjectEntity(
            projectId = "proj_py_calc",
            courseId = "course_python",
            title = "Interactive Smart Calculator CLI",
            difficulty = "Beginner",
            description = "Build a functional command-line calculator that supports addition, subtraction, multiplication, division, exponentiation, and input validation.",
            requirements = "1. Create functions for basic math operations.\n2. Prompt user for operator and two numbers.\n3. Handle division by zero gracefully.\n4. Allow the user to perform continuous calculations until they type 'exit'.",
            language = "python",
            starterCode = "def add(a, b):\n    return a + b\n\ndef subtract(a, b):\n    return a - b\n\n# Implement multiply, divide, and calculator loop here\nprint(\"=== Smart Calculator ===\")\nprint(\"Ready to calculate!\")",
            hints = "Use a `while True:` loop to keep the calculator running, and `break` when the user enters 'quit'.",
            solutionCode = "def calculator():\n    print(\"=== Python Smart Calculator ===\")\n    while True:\n        op = input(\"Enter operation (+, -, *, /) or 'q' to quit: \")\n        if op.lower() == 'q':\n            print(\"Goodbye!\")\n            break\n        try:\n            num1 = float(input(\"First number: \"))\n            num2 = float(input(\"Second number: \"))\n            if op == '+': print(f\"Result: {num1 + num2}\")\n            elif op == '-': print(f\"Result: {num1 - num2}\")\n            elif op == '*': print(f\"Result: {num1 * num2}\")\n            elif op == '/':\n                if num2 == 0: print(\"Error: Division by zero\")\n                else: print(f\"Result: {num1 / num2}\")\n        except ValueError:\n            print(\"Invalid number entered. Try again.\")\n\ncalculator()",
            xpReward = 150,
            coinReward = 50
        ),
        ProjectEntity(
            projectId = "proj_web_todo",
            courseId = "course_webdev",
            title = "Responsive To-Do Task Manager",
            difficulty = "Beginner",
            description = "Create a responsive web-based task manager where students can add tasks, mark items completed with strike-through, filter active tasks, and persist state in localStorage.",
            requirements = "1. Clean HTML input form and list container.\n2. Modern CSS styling with smooth button hover states.\n3. JavaScript event listeners to add, toggle, and delete tasks.\n4. Local storage persistence so tasks remain after refresh.",
            language = "javascript",
            starterCode = "// Task Manager Logic\nconst tasks = [];\n\nfunction addTask(title) {\n  const task = { id: Date.now(), title, completed: false };\n  tasks.push(task);\n  console.log('Task added:', task);\n}\n\naddTask('Complete Code Master AI Lesson');",
            hints = "Use `document.querySelector` and `addEventListener('click', ...)` to interact with the DOM.",
            solutionCode = "class TodoApp {\n  constructor() {\n    this.tasks = JSON.parse(localStorage.getItem('tasks') || '[]');\n  }\n  add(title) {\n    this.tasks.push({ id: Date.now(), title, done: false });\n    this.save();\n  }\n  toggle(id) {\n    const t = this.tasks.find(x => x.id === id);\n    if (t) t.done = !t.done;\n    this.save();\n  }\n  save() {\n    localStorage.setItem('tasks', JSON.stringify(this.tasks));\n  }\n}",
            xpReward = 180,
            coinReward = 60
        )
    )

    val initialAchievements = listOf(
        AchievementEntity(
            achievementId = "ach_first_step",
            title = "First Code Run",
            description = "Execute your first code snippet in Code Master AI.",
            iconName = "play_circle",
            category = "coding",
            xpThreshold = 20,
            isUnlocked = true,
            unlockedDate = "2026-08-20"
        ),
        AchievementEntity(
            achievementId = "ach_streak_3",
            title = "Consistency Champion",
            description = "Maintain a 3-day daily learning streak.",
            iconName = "local_fire_department",
            category = "streak",
            xpThreshold = 100,
            isUnlocked = true,
            unlockedDate = "2026-08-22"
        ),
        AchievementEntity(
            achievementId = "ach_xp_500",
            title = "Code Prodigy",
            description = "Earn 500 Experience Points (XP).",
            iconName = "military_tech",
            category = "xp",
            xpThreshold = 500,
            isUnlocked = false
        ),
        AchievementEntity(
            achievementId = "ach_bug_hunter",
            title = "Bug Hunter",
            description = "Solve 5 debugging challenges in practice mode.",
            iconName = "pest_control",
            category = "debug",
            xpThreshold = 300,
            isUnlocked = false
        ),
        AchievementEntity(
            achievementId = "ach_course_master",
            title = "Course Master",
            description = "Complete an entire course and earn a verifiable certificate.",
            iconName = "workspace_premium",
            category = "courses",
            xpThreshold = 600,
            isUnlocked = false
        )
    )

    val initialDailyChallenge = DailyChallengeEntity(
        challengeId = "daily_20260822",
        dateString = "Aug 22, 2026",
        title = "Palindrome String Checker",
        difficulty = "Easy",
        language = "python",
        description = "Write a function `is_palindrome(text)` that returns `True` if the string reads the same forwards and backwards (ignoring case), otherwise `False`.",
        starterCode = "def is_palindrome(s: str) -> bool:\n    # Write your solution here\n    cleaned = s.lower()\n    return cleaned == cleaned[::-1]\n\n# Test Cases\nprint(\"racecar:\", is_palindrome(\"racecar\"))\nprint(\"hello:\", is_palindrome(\"hello\"))",
        hints = "Hint 1: Convert string to lowercase using `.lower()`.\nHint 2: In Python, `s[::-1]` reverses a string.",
        solutionCode = "def is_palindrome(s: str) -> bool:\n    cleaned = s.lower().replace(' ', '')\n    return cleaned == cleaned[::-1]\n\nprint(is_palindrome(\"Madam\")) # True\nprint(is_palindrome(\"Python\")) # False",
        expectedOutput = "racecar: True\nhello: False",
        xpReward = 50,
        coinReward = 15,
        isCompleted = false
    )

    val initialCommunityPosts = listOf(
        CommunityPostEntity(
            postId = "post_1",
            authorUid = "admin_master_01",
            authorName = "Bhaskar (Lead Architect)",
            authorRole = "admin",
            title = "🚀 Welcome to Code Master AI! How to maximize your learning",
            content = "Welcome all learners! Code Master AI is built to take you from complete beginner to building production applications. Tip: Always try running the code yourself in the lesson editor, toggle 'Explain Simply' if you get stuck, and don't hesitate to ask our AI Tutor!",
            category = "Tip",
            likesCount = 42,
            answersCount = 8,
            createdAt = System.currentTimeMillis() - 86400000L
        ),
        CommunityPostEntity(
            postId = "post_2",
            authorUid = "student_demo_01",
            authorName = "Aarav Sharma",
            authorRole = "student",
            title = "How do list comprehensions work in Python?",
            content = "I see expressions like `[x**2 for x in range(10) if x % 2 == 0]`. Could someone explain how this evaluates step-by-step compared to regular for loops?",
            codeSnippet = "squares = [x**2 for x in range(10) if x % 2 == 0]\nprint(squares)",
            language = "python",
            category = "Question",
            likesCount = 14,
            answersCount = 3,
            createdAt = System.currentTimeMillis() - 36000000L
        )
    )

    val sampleCertificates = listOf(
        CertificateEntity(
            certificateId = "CM-2026-89421",
            uid = "student_demo_01",
            studentName = "Aarav Sharma",
            courseId = "course_python",
            courseName = "Python for Absolute Beginners",
            issueDate = "August 20, 2026",
            courseDurationHours = 12,
            grade = "Distinction (96%)",
            qrCodeHash = "VALID_CERT_CM_2026_89421_BHASKAR_CODEMASTER_AI",
            verifiedBy = "Bhaskar (Lead Architect)"
        )
    )
}
