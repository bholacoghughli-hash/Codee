package com.example.data.repository

import com.example.data.local.dao.DailyChallengeDao
import com.example.data.local.dao.ProjectDao
import com.example.data.local.dao.QuizDao
import com.example.data.local.dao.UserDao
import com.example.data.local.entity.DailyChallengeEntity
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.QuizEntity
import kotlinx.coroutines.flow.Flow

data class PracticeQuestion(
    val id: String,
    val type: String, // "mcq", "bug_hunt", "output_prediction", "fill_blank"
    val question: String,
    val codeSnippet: String? = null,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val hints: List<String>
)

class PracticeAndQuizRepository(
    private val quizDao: QuizDao,
    private val projectDao: ProjectDao,
    private val dailyChallengeDao: DailyChallengeDao,
    private val userDao: UserDao
) {

    fun getTodayChallengeFlow(): Flow<DailyChallengeEntity?> =
        dailyChallengeDao.getTodayChallengeFlow()

    suspend fun completeDailyChallenge(challengeId: String, uid: String, xp: Int, coins: Int) {
        dailyChallengeDao.markCompleted(challengeId)
        userDao.addXpAndCoins(uid, xp, coins)
        userDao.incrementStreak(uid)
    }

    fun getQuizzesForCourseFlow(courseId: String): Flow<List<QuizEntity>> =
        quizDao.getQuizzesForCourseFlow(courseId)

    suspend fun getQuizById(quizId: String): QuizEntity? =
        quizDao.getQuizById(quizId)

    fun getProjectsForCourseFlow(courseId: String): Flow<List<ProjectEntity>> =
        projectDao.getProjectsForCourseFlow(courseId)

    fun getAllProjectsFlow(): Flow<List<ProjectEntity>> =
        projectDao.getAllProjectsFlow()

    suspend fun getProjectById(projectId: String): ProjectEntity? =
        projectDao.getProjectById(projectId)

    // Practice problem catalog
    fun getPracticeSet(category: String, difficulty: String): List<PracticeQuestion> {
        return listOf(
            PracticeQuestion(
                id = "pq_1",
                type = "output_prediction",
                question = "What will be the output of this Python list operation?",
                codeSnippet = "numbers = [1, 2, 3, 4, 5]\nprint(numbers[1:4])",
                options = listOf("[1, 2, 3]", "[2, 3, 4]", "[2, 3, 4, 5]", "[1, 2, 3, 4]"),
                correctIndex = 1,
                explanation = "Slicing `numbers[1:4]` starts at index 1 (value 2) and ends before index 4 (value 4), yielding `[2, 3, 4]`.",
                hints = listOf(
                    "Python list indexing starts at index 0.",
                    "The end index in a slice `[start:end]` is non-inclusive (stops at end - 1)."
                )
            ),
            PracticeQuestion(
                id = "pq_2",
                type = "bug_hunt",
                question = "Identify the bug in this function designed to calculate factorial:",
                codeSnippet = "def factorial(n):\n    if n == 0:\n        return 1\n    return n * factorial(n)",
                options = listOf(
                    "The base case is wrong",
                    "Infinite recursion: should be factorial(n - 1)",
                    "Factorial of 0 is 0, not 1",
                    "Missing type annotation"
                ),
                correctIndex = 1,
                explanation = "Recursive call must decrement `n`: `factorial(n - 1)`, otherwise it leads to RecursionError stack overflow.",
                hints = listOf(
                    "Look at the argument passed into the recursive call on the last line.",
                    "Does `n` ever get smaller towards the base case?"
                )
            ),
            PracticeQuestion(
                id = "pq_3",
                type = "mcq",
                question = "Which keyword in Kotlin creates a read-only, immutable variable?",
                codeSnippet = null,
                options = listOf("var", "val", "const val", "let"),
                correctIndex = 1,
                explanation = "`val` in Kotlin creates a read-only variable whose reference cannot be reassigned.",
                hints = listOf(
                    "Think of 'value' (val) vs 'variable' (var).",
                    "It prevents accidental mutation."
                )
            ),
            PracticeQuestion(
                id = "pq_4",
                type = "output_prediction",
                question = "What does this JavaScript expression evaluate to?",
                codeSnippet = "const a = [1, 2, 3];\nconst b = [...a, 4, 5];\nconsole.log(b.length);",
                options = listOf("3", "4", "5", "undefined"),
                correctIndex = 2,
                explanation = "The spread operator `...a` unpacks 3 elements, and 2 more are added, resulting in a length of 5.",
                hints = listOf(
                    "The spread operator `...` expands the elements of array `a`.",
                    "Count total items in array `b`."
                )
            )
        )
    }
}
