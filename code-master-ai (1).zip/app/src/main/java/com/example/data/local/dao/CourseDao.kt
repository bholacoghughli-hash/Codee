package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.ModuleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CourseDao {
    @Query("SELECT * FROM courses WHERE isPublished = 1 ORDER BY category, title")
    fun getAllPublishedCoursesFlow(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses ORDER BY category, title")
    fun getAllCoursesAdminFlow(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses WHERE courseId = :courseId LIMIT 1")
    fun getCourseFlow(courseId: String): Flow<CourseEntity?>

    @Query("SELECT * FROM courses WHERE courseId = :courseId LIMIT 1")
    suspend fun getCourseById(courseId: String): CourseEntity?

    @Query("SELECT * FROM courses WHERE category = :category AND isPublished = 1")
    fun getCoursesByCategoryFlow(category: String): Flow<List<CourseEntity>>

    @Query("SELECT * FROM modules WHERE courseId = :courseId ORDER BY moduleNumber ASC")
    fun getModulesForCourseFlow(courseId: String): Flow<List<ModuleEntity>>

    @Query("SELECT * FROM modules WHERE courseId = :courseId ORDER BY moduleNumber ASC")
    suspend fun getModulesForCourse(courseId: String): List<ModuleEntity>

    @Query("SELECT * FROM lessons WHERE courseId = :courseId ORDER BY lessonNumber ASC")
    fun getLessonsForCourseFlow(courseId: String): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE moduleId = :moduleId ORDER BY lessonNumber ASC")
    fun getLessonsForModuleFlow(moduleId: String): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE lessonId = :lessonId LIMIT 1")
    fun getLessonFlow(lessonId: String): Flow<LessonEntity?>

    @Query("SELECT * FROM lessons WHERE lessonId = :lessonId LIMIT 1")
    suspend fun getLessonById(lessonId: String): LessonEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourses(courses: List<CourseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: CourseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertModules(modules: List<ModuleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLessons(lessons: List<LessonEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLesson(lesson: LessonEntity)

    @Delete
    suspend fun deleteCourse(course: CourseEntity)

    @Query("DELETE FROM courses WHERE courseId = :courseId")
    suspend fun deleteCourseById(courseId: String)
}
