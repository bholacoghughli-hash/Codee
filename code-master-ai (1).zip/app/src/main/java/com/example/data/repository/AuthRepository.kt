package com.example.data.repository

import com.example.data.local.dao.UserDao
import com.example.data.local.entity.UserEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

sealed class AuthResult<out T> {
    data class Success<T>(val data: T) : AuthResult<T>()
    data class Error(val message: String) : AuthResult<Nothing>()
}

class AuthRepository(private val userDao: UserDao) {

    private val _currentUserId = MutableStateFlow<String?>("student_demo_01") // Defaults to active student session
    val currentUserId: StateFlow<String?> = _currentUserId.asStateFlow()

    fun getCurrentUserFlow(): Flow<UserEntity?> {
        val uid = _currentUserId.value ?: "student_demo_01"
        return userDao.getUserFlow(uid)
    }

    suspend fun getCurrentUser(): UserEntity? {
        val uid = _currentUserId.value ?: return null
        return userDao.getUser(uid)
    }

    suspend fun loginWithEmail(email: String, password: String): AuthResult<UserEntity> {
        val trimmedEmail = email.trim().lowercase()
        if (trimmedEmail.isEmpty() || password.isEmpty()) {
            return AuthResult.Error("Please enter both email and password.")
        }

        // Check if admin login
        if (trimmedEmail == "admin@codemaster.ai") {
            val admin = userDao.getUser("admin_master_01")
            if (admin != null) {
                _currentUserId.value = admin.uid
                return AuthResult.Success(admin)
            }
        }

        val existingUser = userDao.getUserByEmail(trimmedEmail)
        if (existingUser != null) {
            if (existingUser.accountStatus == "deactivated") {
                return AuthResult.Error("This account has been deactivated by the Administrator.")
            }
            _currentUserId.value = existingUser.uid
            return AuthResult.Success(existingUser)
        }

        // Auto-register student if valid credentials provided for seamless onboarding
        val newStudent = UserEntity(
            uid = "user_" + UUID.randomUUID().toString().take(8),
            fullName = trimmedEmail.substringBefore("@").replace(".", " ").replaceFirstChar { it.uppercase() },
            email = trimmedEmail,
            role = "student",
            preferredLanguage = "English",
            learningLevel = "Beginner",
            learningGoal = "Full-Stack Development",
            xp = 50,
            coins = 20,
            level = 1,
            streak = 1
        )
        userDao.insertUser(newStudent)
        _currentUserId.value = newStudent.uid
        return AuthResult.Success(newStudent)
    }

    suspend fun registerStudent(
        fullName: String,
        email: String,
        phone: String,
        preferredLanguage: String,
        learningLevel: String,
        learningGoal: String,
        country: String
    ): AuthResult<UserEntity> {
        val trimmedEmail = email.trim().lowercase()
        if (fullName.isBlank()) return AuthResult.Error("Full Name is required.")
        if (trimmedEmail.isBlank() || !trimmedEmail.contains("@")) return AuthResult.Error("Please enter a valid email address.")

        val existing = userDao.getUserByEmail(trimmedEmail)
        if (existing != null) {
            return AuthResult.Error("An account with this email already exists. Please log in.")
        }

        // Normal registration always creates a student role
        val newStudent = UserEntity(
            uid = "student_" + UUID.randomUUID().toString().take(8),
            fullName = fullName.trim(),
            email = trimmedEmail,
            phoneNumber = phone.trim(),
            role = "student",
            preferredLanguage = preferredLanguage,
            learningLevel = learningLevel,
            learningGoal = learningGoal,
            country = country,
            xp = 100, // Welcome bonus XP
            coins = 30,
            level = 1,
            streak = 1
        )
        userDao.insertUser(newStudent)
        _currentUserId.value = newStudent.uid
        return AuthResult.Success(newStudent)
    }

    suspend fun loginWithGoogle(email: String, displayName: String, photoUrl: String = ""): AuthResult<UserEntity> {
        val trimmedEmail = email.trim().lowercase()
        val existing = userDao.getUserByEmail(trimmedEmail)
        if (existing != null) {
            _currentUserId.value = existing.uid
            return AuthResult.Success(existing)
        }

        val newGoogleUser = UserEntity(
            uid = "google_" + UUID.randomUUID().toString().take(8),
            fullName = displayName.ifBlank { "Learner" },
            email = trimmedEmail,
            profilePhoto = photoUrl,
            role = "student", // Google logins are ALWAYS student role
            preferredLanguage = "English",
            learningLevel = "Beginner",
            learningGoal = "Build Coding Projects",
            xp = 100,
            coins = 30
        )
        userDao.insertUser(newGoogleUser)
        _currentUserId.value = newGoogleUser.uid
        return AuthResult.Success(newGoogleUser)
    }

    suspend fun verifyPhoneOtp(phoneNumber: String, otpCode: String): AuthResult<UserEntity> {
        if (otpCode.length != 6) {
            return AuthResult.Error("Please enter a valid 6-digit verification code.")
        }
        val cleanPhone = phoneNumber.trim()
        val existing = userDao.getUserByPhone(cleanPhone)
        if (existing != null) {
            _currentUserId.value = existing.uid
            return AuthResult.Success(existing)
        }

        val newPhoneUser = UserEntity(
            uid = "phone_" + UUID.randomUUID().toString().take(8),
            fullName = "Coder " + cleanPhone.takeLast(4),
            email = "user_${cleanPhone.takeLast(4)}@codemaster.ai",
            phoneNumber = cleanPhone,
            role = "student",
            xp = 100,
            coins = 30
        )
        userDao.insertUser(newPhoneUser)
        _currentUserId.value = newPhoneUser.uid
        return AuthResult.Success(newPhoneUser)
    }

    suspend fun switchToAdminSession(): UserEntity? {
        val admin = userDao.getUser("admin_master_01")
        if (admin != null) {
            _currentUserId.value = admin.uid
        }
        return admin
    }

    suspend fun switchToStudentSession(): UserEntity? {
        val student = userDao.getUser("student_demo_01")
        if (student != null) {
            _currentUserId.value = student.uid
        }
        return student
    }

    suspend fun updateUserProfile(
        fullName: String,
        preferredLanguage: String,
        learningLevel: String,
        learningGoal: String
    ) {
        val currentUser = getCurrentUser() ?: return
        val updated = currentUser.copy(
            fullName = fullName,
            preferredLanguage = preferredLanguage,
            learningLevel = learningLevel,
            learningGoal = learningGoal
        )
        userDao.updateUser(updated)
    }

    suspend fun toggleAccountStatus(targetUid: String, newStatus: String) {
        userDao.updateAccountStatus(targetUid, newStatus)
    }

    fun getAllStudentsFlow(): Flow<List<UserEntity>> = userDao.getAllStudentsFlow()

    fun searchStudentsFlow(query: String): Flow<List<UserEntity>> = userDao.searchStudentsFlow(query)

    suspend fun logout() {
        _currentUserId.value = null
    }

    suspend fun deleteAccount() {
        val uid = _currentUserId.value ?: return
        userDao.deleteUser(uid)
        _currentUserId.value = null
    }
}
