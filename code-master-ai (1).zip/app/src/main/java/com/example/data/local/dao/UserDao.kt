package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE uid = :uid LIMIT 1")
    fun getUserFlow(uid: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE uid = :uid LIMIT 1")
    suspend fun getUser(uid: String): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE phoneNumber = :phone LIMIT 1")
    suspend fun getUserByPhone(phone: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET xp = xp + :xpGained, coins = coins + :coinsGained WHERE uid = :uid")
    suspend fun addXpAndCoins(uid: String, xpGained: Int, coinsGained: Int)

    @Query("UPDATE users SET level = :newLevel WHERE uid = :uid")
    suspend fun updateLevel(uid: String, newLevel: Int)

    @Query("UPDATE users SET streak = streak + 1 WHERE uid = :uid")
    suspend fun incrementStreak(uid: String)

    @Query("UPDATE users SET accountStatus = :status WHERE uid = :uid")
    suspend fun updateAccountStatus(uid: String, status: String)

    @Query("SELECT * FROM users WHERE role = 'student' ORDER BY xp DESC")
    fun getAllStudentsFlow(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE role = 'student' ORDER BY xp DESC")
    suspend fun getAllStudents(): List<UserEntity>

    @Query("SELECT * FROM users WHERE role = 'student' AND (fullName LIKE '%' || :query || '%' OR email LIKE '%' || :query || '%')")
    fun searchStudentsFlow(query: String): Flow<List<UserEntity>>

    @Query("DELETE FROM users WHERE uid = :uid")
    suspend fun deleteUser(uid: String)
}
