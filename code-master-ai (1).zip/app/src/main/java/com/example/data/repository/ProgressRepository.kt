package com.example.data.repository

import com.example.data.local.dao.AchievementDao
import com.example.data.local.dao.CertificateDao
import com.example.data.local.dao.ProgressDao
import com.example.data.local.dao.UserDao
import com.example.data.local.entity.AchievementEntity
import com.example.data.local.entity.CertificateEntity
import com.example.data.local.entity.UserProgressEntity
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

class ProgressRepository(
    private val progressDao: ProgressDao,
    private val userDao: UserDao,
    private val certificateDao: CertificateDao,
    private val achievementDao: AchievementDao
) {

    fun getProgressFlow(uid: String, courseId: String): Flow<UserProgressEntity?> =
        progressDao.getProgressFlow(uid, courseId)

    fun getAllProgressForUserFlow(uid: String): Flow<List<UserProgressEntity>> =
        progressDao.getAllProgressForUserFlow(uid)

    fun getCertificatesForUserFlow(uid: String): Flow<List<CertificateEntity>> =
        certificateDao.getCertificatesForUserFlow(uid)

    fun getAllCertificatesFlow(): Flow<List<CertificateEntity>> =
        certificateDao.getAllCertificatesFlow()

    suspend fun getCertificateById(certificateId: String): CertificateEntity? =
        certificateDao.getCertificateById(certificateId)

    fun getAllAchievementsFlow(): Flow<List<AchievementEntity>> =
        achievementDao.getAllAchievementsFlow()

    suspend fun completeLesson(
        uid: String,
        courseId: String,
        lessonId: String,
        xpEarned: Int,
        coinsEarned: Int,
        totalLessonsInCourse: Int
    ) {
        // 1. Update Progress record
        val currentProgress = progressDao.getProgress(uid, courseId)
        val completedList = currentProgress?.completedLessonIds?.split(",")?.filter { it.isNotBlank() }?.toMutableSet() ?: mutableSetOf()
        completedList.add(lessonId)
        val completedString = completedList.joinToString(",")

        val percent = if (totalLessonsInCourse > 0) {
            ((completedList.size.toFloat() / totalLessonsInCourse) * 100).toInt().coerceAtMost(100)
        } else 0

        val isCourseFinished = percent >= 100

        val updatedProgress = UserProgressEntity(
            id = "${uid}_${courseId}",
            uid = uid,
            courseId = courseId,
            completedLessonIds = completedString,
            completedQuizIds = currentProgress?.completedQuizIds ?: "",
            completedProjectIds = currentProgress?.completedProjectIds ?: "",
            isCompleted = isCourseFinished,
            percentCompleted = percent,
            lastAccessedLessonId = lessonId,
            updatedAt = System.currentTimeMillis()
        )
        progressDao.insertProgress(updatedProgress)

        // 2. Award XP and Coins to user
        userDao.addXpAndCoins(uid, xpEarned, coinsEarned)

        // 3. Check level update (Level = (XP / 200) + 1)
        val user = userDao.getUser(uid)
        if (user != null) {
            val calculatedLevel = (user.xp / 200) + 1
            if (calculatedLevel > user.level) {
                userDao.updateLevel(uid, calculatedLevel)
            }
        }

        // 4. If course completed, auto-generate certificate
        if (isCourseFinished) {
            generateCertificateForUser(uid, courseId)
        }
    }

    suspend fun generateCertificateForUser(uid: String, courseId: String): CertificateEntity {
        val user = userDao.getUser(uid)
        val studentName = user?.fullName ?: "Dedicated Learner"
        val courseName = when (courseId) {
            "course_python" -> "Python for Absolute Beginners"
            "course_webdev" -> "Modern Web Dev: HTML, CSS & JavaScript"
            "course_kotlin" -> "Kotlin & Android Jetpack Compose"
            "course_sql" -> "SQL & Relational Database Mastery"
            "course_genai" -> "Generative AI & Prompt Engineering"
            "course_dsa" -> "Data Structures & Algorithms in Practice"
            else -> "Advanced Software Engineering"
        }

        val randomSuffix = (10000..99999).random()
        val certId = "CM-2026-$randomSuffix"
        val currentDate = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(Date())

        val cert = CertificateEntity(
            certificateId = certId,
            uid = uid,
            studentName = studentName,
            courseId = courseId,
            courseName = courseName,
            issueDate = currentDate,
            courseDurationHours = 12,
            grade = "Distinction (Honors)",
            qrCodeHash = "VERIFIED_CERT_${certId}_BHASKAR_CODEMASTER_AI",
            verifiedBy = "Bhaskar (Lead Architect)"
        )
        certificateDao.insertCertificate(cert)
        return cert
    }
}
