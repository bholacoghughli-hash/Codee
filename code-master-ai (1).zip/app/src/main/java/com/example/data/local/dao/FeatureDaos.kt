package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {
    @Query("SELECT * FROM user_progress WHERE uid = :uid")
    fun getAllProgressForUserFlow(uid: String): Flow<List<UserProgressEntity>>

    @Query("SELECT * FROM user_progress WHERE uid = :uid AND courseId = :courseId LIMIT 1")
    fun getProgressFlow(uid: String, courseId: String): Flow<UserProgressEntity?>

    @Query("SELECT * FROM user_progress WHERE uid = :uid AND courseId = :courseId LIMIT 1")
    suspend fun getProgress(uid: String, courseId: String): UserProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: UserProgressEntity)

    @Update
    suspend fun updateProgress(progress: UserProgressEntity)
}

@Dao
interface QuizDao {
    @Query("SELECT * FROM quizzes WHERE courseId = :courseId")
    fun getQuizzesForCourseFlow(courseId: String): Flow<List<QuizEntity>>

    @Query("SELECT * FROM quizzes WHERE quizId = :quizId LIMIT 1")
    suspend fun getQuizById(quizId: String): QuizEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizzes(quizzes: List<QuizEntity>)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE courseId = :courseId")
    fun getProjectsForCourseFlow(courseId: String): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects")
    fun getAllProjectsFlow(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE projectId = :projectId LIMIT 1")
    suspend fun getProjectById(projectId: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProjects(projects: List<ProjectEntity>)
}

@Dao
interface CertificateDao {
    @Query("SELECT * FROM certificates WHERE uid = :uid ORDER BY issuedTimestamp DESC")
    fun getCertificatesForUserFlow(uid: String): Flow<List<CertificateEntity>>

    @Query("SELECT * FROM certificates ORDER BY issuedTimestamp DESC")
    fun getAllCertificatesFlow(): Flow<List<CertificateEntity>>

    @Query("SELECT * FROM certificates WHERE certificateId = :certificateId LIMIT 1")
    suspend fun getCertificateById(certificateId: String): CertificateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCertificate(certificate: CertificateEntity)
}

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements ORDER BY isUnlocked DESC, xpThreshold ASC")
    fun getAllAchievementsFlow(): Flow<List<AchievementEntity>>

    @Query("UPDATE achievements SET isUnlocked = 1, unlockedDate = :date WHERE achievementId = :id")
    suspend fun unlockAchievement(id: String, date: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievements(achievements: List<AchievementEntity>)
}

@Dao
interface DailyChallengeDao {
    @Query("SELECT * FROM daily_challenges ORDER BY challengeId DESC LIMIT 1")
    fun getTodayChallengeFlow(): Flow<DailyChallengeEntity?>

    @Query("UPDATE daily_challenges SET isCompleted = 1 WHERE challengeId = :challengeId")
    suspend fun markCompleted(challengeId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChallenges(challenges: List<DailyChallengeEntity>)
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks WHERE uid = :uid ORDER BY createdAt DESC")
    fun getBookmarksForUserFlow(uid: String): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE uid = :uid AND lessonId = :lessonId)")
    fun isBookmarkedFlow(uid: String, lessonId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE uid = :uid AND lessonId = :lessonId")
    suspend fun deleteBookmark(uid: String, lessonId: String)
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE uid = :uid ORDER BY updatedAt DESC")
    fun getNotesForUserFlow(uid: String): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE uid = :uid AND lessonId = :lessonId LIMIT 1")
    fun getNoteForLessonFlow(uid: String, lessonId: String): Flow<NoteEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE noteId = :noteId")
    suspend fun deleteNote(noteId: String)
}

@Dao
interface CommunityDao {
    @Query("SELECT * FROM community_posts WHERE isReported = 0 ORDER BY createdAt DESC")
    fun getAllPostsFlow(): Flow<List<CommunityPostEntity>>

    @Query("SELECT * FROM community_posts WHERE isReported = 1 ORDER BY createdAt DESC")
    fun getReportedPostsFlow(): Flow<List<CommunityPostEntity>>

    @Query("SELECT * FROM community_posts WHERE category = :category AND isReported = 0 ORDER BY createdAt DESC")
    fun getPostsByCategoryFlow(category: String): Flow<List<CommunityPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: CommunityPostEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<CommunityPostEntity>)

    @Query("UPDATE community_posts SET likesCount = likesCount + 1 WHERE postId = :postId")
    suspend fun likePost(postId: String)

    @Query("UPDATE community_posts SET isReported = 1 WHERE postId = :postId")
    suspend fun reportPost(postId: String)

    @Query("DELETE FROM community_posts WHERE postId = :postId")
    suspend fun deletePost(postId: String)
}

@Dao
interface PlaygroundDao {
    @Query("SELECT * FROM playground_files WHERE uid = :uid ORDER BY updatedAt DESC")
    fun getFilesForUserFlow(uid: String): Flow<List<PlaygroundFileEntity>>

    @Query("SELECT * FROM playground_files WHERE fileId = :fileId LIMIT 1")
    suspend fun getFileById(fileId: String): PlaygroundFileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveFile(file: PlaygroundFileEntity)

    @Query("DELETE FROM playground_files WHERE fileId = :fileId")
    suspend fun deleteFile(fileId: String)
}
