package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_progress")
data class UserProgressEntity(
    @PrimaryKey val id: String, // "${uid}_${courseId}"
    val uid: String,
    val courseId: String,
    val completedLessonIds: String = "", // comma-separated lessonIds
    val completedQuizIds: String = "",
    val completedProjectIds: String = "",
    val isCompleted: Boolean = false,
    val percentCompleted: Int = 0,
    val lastAccessedLessonId: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "quizzes")
data class QuizEntity(
    @PrimaryKey val quizId: String,
    val courseId: String,
    val moduleId: String,
    val title: String,
    val timeLimitMinutes: Int = 10,
    val passingScorePercent: Int = 70,
    val xpReward: Int = 50,
    val coinReward: Int = 15,
    val questionsData: String // Serialized questions (JSON string or structured)
)

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val projectId: String,
    val courseId: String,
    val title: String,
    val difficulty: String, // Beginner, Intermediate, Advanced
    val description: String,
    val requirements: String, // newline separated or structured
    val language: String,
    val starterCode: String,
    val hints: String,
    val solutionCode: String,
    val xpReward: Int = 100,
    val coinReward: Int = 30
)

@Entity(tableName = "certificates")
data class CertificateEntity(
    @PrimaryKey val certificateId: String, // e.g. "CM-2026-89421"
    val uid: String,
    val studentName: String,
    val courseId: String,
    val courseName: String,
    val issueDate: String,
    val courseDurationHours: Int,
    val grade: String = "Distinction",
    val qrCodeHash: String,
    val verifiedBy: String = "Bhaskar (Lead Architect)",
    val isShared: Boolean = false,
    val issuedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val achievementId: String,
    val title: String,
    val description: String,
    val iconName: String,
    val category: String, // streak, xp, courses, coding, debug
    val xpThreshold: Int = 0,
    val isUnlocked: Boolean = false,
    val unlockedDate: String = ""
)

@Entity(tableName = "daily_challenges")
data class DailyChallengeEntity(
    @PrimaryKey val challengeId: String,
    val dateString: String,
    val title: String,
    val difficulty: String, // Easy, Medium, Hard
    val language: String,
    val description: String,
    val starterCode: String,
    val hints: String,
    val solutionCode: String,
    val expectedOutput: String,
    val xpReward: Int = 40,
    val coinReward: Int = 10,
    val isCompleted: Boolean = false
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val bookmarkId: String,
    val uid: String,
    val lessonId: String,
    val courseId: String,
    val lessonTitle: String,
    val courseTitle: String,
    val codeSnippet: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val noteId: String,
    val uid: String,
    val lessonId: String,
    val lessonTitle: String,
    val noteContent: String,
    val tag: String = "General",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "community_posts")
data class CommunityPostEntity(
    @PrimaryKey val postId: String,
    val authorUid: String,
    val authorName: String,
    val authorRole: String = "student",
    val title: String,
    val content: String,
    val codeSnippet: String = "",
    val language: String = "",
    val category: String = "Question", // Question, Project Showcase, Doubt, Tip
    val likesCount: Int = 0,
    val answersCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val isResolved: Boolean = false,
    val isReported: Boolean = false
)

@Entity(tableName = "playground_files")
data class PlaygroundFileEntity(
    @PrimaryKey val fileId: String,
    val uid: String,
    val fileName: String,
    val language: String, // python, js, html, kotlin, cpp, sql
    val codeContent: String,
    val updatedAt: Long = System.currentTimeMillis()
)
