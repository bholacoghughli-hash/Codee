package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.data.local.CodeMasterDatabase
import com.example.ui.navigation.MainApp
import com.example.ui.theme.CodeMasterTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

  private val database by lazy {
    CodeMasterDatabase.getDatabase(this)
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Ensure database seed data is initialized
    CoroutineScope(Dispatchers.IO).launch {
      val users = database.userDao().getUser("admin_master_01")
      if (users == null) {
        CodeMasterDatabase.populateDatabase(database)
      }
    }

    setContent {
      CodeMasterTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = MaterialTheme.colorScheme.background
        ) {
          MainApp(database = database)
        }
      }
    }
  }
}

